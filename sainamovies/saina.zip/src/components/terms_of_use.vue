<template>
     <div id="bg" class="uk-width-1-1@m" style="background-color:black;width:-webkit-fill-available;">
         <router-link v-bind:to="'/movies'" >
            <img id="navimg" src="../assets/images/sainalogin1.png" style="width: 60px;margin-left:100px;margin-top:30px;" >
                <!-- <a id="navfont" style="color:darkorange;font-size:90px;text-decoration:none;" class="uk-text-capitalize "> Saina</a>   -->
        </router-link>
         <div class="uk-container uk-container-large uk-margin-large-left uk-margin-large-right uk-margin-large-top" style="padding-top:50px; padding-bottom:100px;background:#131311">
            <h3 >TERMS OF USE</h3> 

    <p>As updated on 26/12/2018.</p>

	<p> You for using Saina Video Vision, Our App, Saina Play, and/or Our Website, www.sainavideo.com(“We” or “Us” or “Platform” as the case may be). These terms and conditions of use (“Terms”) govern the use of Our Platform and the content appearing on Our Platform(s) by all members of the Platform (“Users” or “You” or “Your”). These Terms should be read concurrently with our Privacy Policy and such other policies as may be applicable from time to time at sainavideo.com/privacypolicy (collectively the “Policies”).</p>

<p> 1.	WHO WE ARE AND WHAT WE PROVIDE</p> 

<p> 1.1	This Platform is owned by Saina Audio & Video having its registered office at Gandhibazar, PP Road, Perumbavoor-683574.</p> 
<p> 1.2	We provide personalized service that assists you in discovering your best-loved video content in the form of Malayalam movies including all features, functionalities, reviews, recommendations (“Service”). Our Service can be availed through internet on any internet-connected device. </p> 

<p> 2.	YOUR LEGAL AGREEMENT WITH US</p> 
<p> 2.1	If You are using this Platform or Services provided in the Platform you are legally bound by these Terms. If you do not agree to these Terms or our Policies please refrain from using our Platform. </p> 
<p> 2.2	Third party content on the Platform shall have their respective Terms and if You are using third party content through our Platform, You shall also be bound by the respective terms and policies stipulated by such third parties.  </p> 

<p> 3.	AMENDMENTS:</p> 

<p> We may modify these Terms at our discretion (“Amendments”) without prior notice to you. The modified Terms shall be updated on our Platform with the date of latest revision. You are requested to keep checking these Terms to keep yourself abreast about the Amendments made. Your use of the Platform shall be governed by the latest Amendment made to the Terms. </p> 

<p> 4.	WHO CAN USE</p> 

<p> 4.1	Only those persons who are eligible to contract legally (e.g. persons who are above 18 years of age, persons of sound mind etc.) can use the Platform. </p> 
<p> 4.2	If you are part of any legal entity, you are to use this Platform only if you can represent and warrant that you are authorized to do so and have the authority to bind your legal entity to these Terms.</p> 
<p> 4.3	If You are a minor (below 18 years of age), Your use of this Platform shall mean that Your legal guardian has given You his/her implied consent. </p> 
<p> 4.4	Please note that we have the right to terminate Your membership on our Platform if We have reason to believe that you are in breach of any of our Terms or Policies or applicable laws. </p> 

<p> 5.	OUR SERVICES</p> 

<p> 5.1	Our Platform provides our members access to a wide range of Malayalam movies. You will be able to search for your favourite movies and view them on our Platform at your discretion.   </p> 
<p> 5.2	Our Services are available only in the geographic locations where we offer them and where we have licensed the contents on our Platform. You may use our Platform in a number of devices depending upon your subscription plan.</p> 
<p> 5.3	The content on the Platform is updated frequently. </p> 

<p> 5.4	The time it takes to begin watching the content on our Platform will vary based on your location, available bandwidth at the time, the content you have selected and the configuration of your device. The videos available on our Platform are of varied quality and the display quality shall be varied from medium to medium.</p> 

<p> 5.5	Our software shall be different for each medium that You use to access our Platforms, which needs to be maintained as it is for your using of our Platforms. As and when the software is updated, it shall automatically be updated in your devices, without which your use of our Platforms may be hampered.   </p> 

<p> 5.6	You only have a limited, non-exclusive, revocable, non-assignable and non-transferable right and license to the non-commercial use of our Platform which is subject to Your strict compliance of Our Terms and Policies.  </p> 

<p> 6.	MEMBERSHIP AND REGISTRATION</p>

<p> 6.1	You can be a member of Our Platform if you have internet access, a device on which our Platform is compatible with and pay us your membership fee. We may provide you a free trial before your membership is confirmed with us (“Free Trial”). The free trial would be for 10 days period and this is a promotion offer only so that members can truly experience the quality of our Services and get convinced of taking a membership with Us. Free Trial is only provided upon Our discretion, which can be revoked at any time and for any reason. You are prohibited from misusing Free Trial in any manner whatsoever.  </p> 
<p> 6.2	Subscription plans for accessing the Platform and availing the Services are available on the Platforms (“Subscription Plan”): sainavideo.com/plansWe may provide other membership plans from time to time including promotional plans. Membership plans will be on a monthly basis and payment for each month should be done to Us in the beginning of the month.</p>  
<p> 6.3	You may provide your membership fee (“Subscription Amount”) through any valid payment method which is acceptable to Us including payment through netbanking, VISA/MASTERCARD payments or any other mode which is available on our Platform. Your mode of payment shall be saved, with your consent, and the Subscription Amount shall be deducted automatically at the beginning of each month unless you terminate the Services before such deduction. Please note that depending on your payment method, other fees will be charged to your account over and above the Subscription Amount that is shown on our Platform. Local taxes depending upon your location shall also be charged over and above the Subscription Amount.</p> 
<p> 6.4	You shall remain responsible for any unpaid amount due to us. Unless payment is provided, we shall suspend your access to our Platform. We may change our Subscription Plans and the type of Subscription Plans any time. Any price changes to the Subscription Plans will apply only after give you prior notice of at least 30 days.</p> 

<p> 7.	USER NAME AND PASSWORD</p>

<p> Upon your payment of Subscription Amount in accordance with our Subscription plan and providing Us all mandatory details including phone no. e-mail address etc., you shall be provided a user name and password. All the details provided by You shall be accurate and You shall be responsible for providing any incorrect information. You shall not be able to access Our Platforms without providing us all information accurately. </p> 

<p> You may be required to change Your password in case of any suspicious activities upon our notification. Your registered account on Our Platform is personal to you and is non-transferable to any other person or entity. However, as mentioned above, with Your registered account, You may use our Platform in the number of devices as permitted by Your Subscription Plan.</p> 

<p> 8.	DISCLAIMERS</p>
<p> 8.1	Our Services are provided on an ‘as is’ and ‘as available’ basis. Service may be interrupted at times causing you to lose some data or the type of Service may change from time to time or be discontinued or limited for any reason (specifically to You or in general) without any risk or responsibility from Us. Your Use of our Services shall be at your own risk. </p> 
<p> 8.2	It is Our goal to offer reliable quality of Services. However, We offer no guarantees or warranties and to the extent permitted by law, We disclaim all warranties, whether express or implied, including the implied warranties of merchantability, fitness for a particular purpose, title and non-infringement. No warranties are made that the Platform will be available on a consistent basis, that defects in the Platform will be corrected in a timely manner or that the Platform will be free of viruses or other harmful materials. </p>
<p> 8.3	We are not liable to You or any third party (for any monetary or other damage suffered by You or such third party) owing to any omissions, errors, inaccuracies, delays, failures, interruptions, viruses, defects, deletions, failure in networks or communications lines, destruction, theft or unauthorized access to Your network, system or computer. </p> 
<p> 8.4	We shall have no responsibility or onus or liability over third party content available through the Platform. User discretion is advised on viewing contents available on the Platform.</p> 
<p> 8.5	We shall not be held responsible and expressly disclaim any liability whatsoever for any claims, demands or damages, direct or indirect, of every kind and nature, known and unknown, suspected and unsuspected, disclosed and undisclosed, arising out of or in any way connected with the Services.</p> 
 
<p> 9.	TERMINATION OR SUSPENSION OF YOUR SERVICES:</p>
<p> 9.1	You may cancel your membership at any time, and you will continue to have access to our Platform till the end of your chosen Subscription Plan. Please note no refunds shall be provided for cancellation in between a Subscription Plan period or for not using the Platform during the Subscription Plan period. To the extent permitted by the applicable law, payments are non-refundable and we do not provide refunds or credits for any partial-month membership periods or unwatched content. To cancel the account you may use the option of ‘delete account’ available on our Platforms. If you deactivate your account with Us or stop using our Services, You shall no longer be bound by these Terms, except your liability to Us with respect to our Intellectual Property Right related to the Platforms and Services. </p>
<p> 9.2	We reserve our right to terminate your membership at our sole discretion. Any termination or suspension of Your account will not affect Your liability to Us.</p>
<p> 10.	CONFIDENTIALITY</p>

<p> You shall be responsible for maintaining the confidentiality of Your account with Us. If You are made aware of any unauthorized use of your account, You shall inform us immediately. </p>

<p> 11.	YOUR LIABILITY</p>
<p> 11.1	You shall be responsible for the use of the Platforms and the Services provided. You should maintain control over your account on our Platforms and not reveal the password or details of the payment method associated with the account to anyone.</p>
<p> 11.2	You shall indemnify us for any loss incurred to Us due to any unauthorized use of Your account and/or breach of these Terms or caused by You in any other manner from Your use of the Platform or Services. </p>

<p> 12.	INTELLECTUAL PROPERTY RIGHTS: </p>
<p> 12.1	The content available on the Platform shall belong to third parties or Us. All Intellectual Property Rights (as defined below) shall belong to the respective parties whose name the Intellectual Property Right is indicated as belonging to.</p>
<p> 12.2	The Platform including its look and feel belongs to Us and we have all the Intellectual Property Rights associated with the Platform. </p>
<p> 12.3	No infringement of the Intellectual Property Rights pertaining to the Platform or the content available on the Platform is permitted. </p>
<p> 12.4	You are also not allowed to access or tamper with non-public areas of Service, forge any TCP/IP packet header or any part of the header information or in any way use the Services to send altered, deceptive, or false source-identifying information interfere with, or disrupt, the access of any User, host, or network, including sending a virus, overloading, flooding, spamming, mail-bombing the Services and/or Platform(s), or by scripting the creation of content or accounts in such a manner as to interfere with or create an undue burden on the Services and/or Platform(s)</p>
<p> 12.5	Use of any content and materials for any purpose not expressly permitted in these Terms or against applicable law, is prohibited.</p>
<p> 12.6	We are not liable for any infringement of Intellectual Property Rights by You.  </p>
<p> 12.7	You are not allowed to sell, license, rent, modify, distribute or re-distribute, copy, reproduce, transmit, publicly display, publicly perform, publish, adapt, edit, record or create derivative works from any materials or Content accessible through the Platform.</p>
<p> 12.8	We are not responsible for the similarity of any of any content or programming in any media to materials or ideas transmitted to Us.</p>
<p> 12.9	The term Intellectual Property Rights shall mean and include all intellectual property rights whether registered or unregistered including all copyrights which shall include the exclusive right to make and distribute copies of, , display and perform the copyrighted work and to prepare works derived from the original copyrighted work), software and source codes, trademark rights, patent rights, trade names or business names,  design rights,  mask-work rights, trade secrets, moral rights, author’s rights, rights in packaging, goodwill and other intellectual property rights, and all renewals and extension thereof and all rights or forms of protection of a similar nature or having an equivalent or similar effect to any of the above, which may subsist anywhere in the world, regardless of whether any of such rights arise under the laws of India or any other state, country or jurisdiction.</p>

<p> 13.	RESPONSIBILITY OF USER:</p>

<p> 13.1	User is responsible to follow all the norms of applicable law and standard decorum in using the Platform and Services. </p>
<p> 13.2	You shall not:</p>
<p> a)	interfere with or disrupt the Platform or Services;</p>
<p> b)	attempt to gain unauthorized access to any part of the Platform;</p>
<p> c)	disrupt or interfere with the security of the Platform;</p>
<p> d)	collect or store data about other users;</p>
<p> e)	improperly use the Platform;</p>
<p> f)	create or transmit unwanted electronic communications such as “spam,” to other users or members of the Platform or otherwise interfere with other users’ or members’ enjoyment of the Services;</p>
<p> g)	disseminate, upload or transmit malicious or invasive code or program;</p>
<p> h)	archive, reproduce, distribute, modify, display, perform, publish, license, create derivative works from, offer for sale, or use (except as explicitly authorized in these Terms of Use) content and information contained on or obtained from or through the Platforms;</p>
<p> i)	circumvent, remove, alter, deactivate, degrade or thwart any of the content protections in the Platform;</p>
<p> j)	use any robot, spider, scraper or other automated means to access the Platform or Services; </p>
<p> k)	decompile, reverse engineer or disassemble any software or other products or processes accessible through the Platform;</p>
<p> l)	use the Platform through any proxy servers or VPNs</p>
<p> m)	use the Platform for any illegal activities or against applicable laws.</p>

<p> 13.3	We reserve the right at our sole discretion to investigate either by ourselves or using external agencies any suspected breach of Your responsibilities as a User as set out in this Clause 13 and/or to report suspected illegal activities to law enforcement agencies having jurisdiction.</p>

<p> 14.	APPLICABLE LAW</p>

<p> These Terms and Policies are governed by the laws of India and the place of jurisdiction shall be courts in Cochin, Kerala, India exclusively. We shall have the right to institute proceedings against You in any other jurisdiction. </p>

<p> 15.	MISCELLANEOUS:</p>

<p> 15.1	A failure to exercise or delay in exercising any right will not operate as a waiver of that right. </p>
<p> 15.2	If any provision of these Terms is invalid or unenforceable in whole or in part the remaining part of such provision and all other provisions of these Terms shall continue to be in full force and effect.</p>
<p> 15.3	None of the provisions of these Terms shall be deemed to constitute a partnership or agency between You and Us. </p>
<p> 15.4	Any notice issued under these Terms shall be presumed to have been delivered, if 12 hours have passed after an e-mail with the notice is sent to the e-mail address of the concerned party, unless the sending party is notified that the e-mail address is invalid. Notices may also be given by certified mail, postage prepaid to the last known address of the receiving party which was available with the other party, which shall be effective once it is sent.</p>
<p> 15.5	You may contact us for any queries or for reporting any abuse of Our Terms or Policies at sainavideo.com/aboutus.  In the event of any conflict between these Terms and information provided by our customer care team or other portions of our website, these Terms will prevail.</p>
<p> 15.6	In accordance with Information Technology Act 2000 and rules made there under, the name and contact details of the Grievance Officer are provided below:</p>
<p> Name: [Aashiq Bava]</p>
<p> E-mail id: [aashiq.bava@gmail.com]</p>
<hr class="uk-divider-icon">
<h3>PRIVACY POLICY </h3>
 



 

<p>As updated on 26/12/2018 </p>

<p>Thank You for using Saina Video Vision, Our App, Saina Play, and/or Our Website, Sainavideo.com (“We” or “Us” or “Platform” as the case may be). This Privacy Policy (“Policy”) governs the use of Our Platform and the content appearing on Our Platform by all members of the Platform (“Users” or “You” or “Your”). These Terms should be read concurrently with our Terms of Use (the “Terms”). </p>

<p>DEFINITIONS: </p>

 

<p>“Information" shall mean any information You provide Us or give us access to in any form. E.g. your details while registering with us, the videos you viewed etc.  </p>

<p>“Personal Information” shall mean Information disclosed by or obtained from any user of the Platform(s) or by using the Services. e.g. age, any other personal details capable of identifying You. </p>

<p>Capitalized terms used here, which are not defined here will have the same definition as that used in the Terms. </p>

 

 

<p>PURPOSE OF THIS POLICY AND WHY WE COLLECT PERSONAL INFORMATION:  </p>

 

<p>Your privacy is important to Us. This Policy will familiarize You with the manner in which We collect, use and disclose Your Personal Information. Your Personal Information is collected to improve Your experience on the Platform and Services and to provide You Services which are specifically meant for You. We only collect information which is quite necessary for this purpose.  </p>

 

<p>AMENDMENTS: </p>

 

<p>We may modify this Policy at our discretion (“Amendments”) without prior notice to you. The modified Policy shall be updated on our Platform with the date of latest revision. You are requested to keep checking this Policy on the Platform to keep yourself abreast with the Amendments made.  </p>

 

<p>INFORMATION WE COLLECT: </p>

 

<p>You can browse the Platform without providing any Personal Information. However, other identifiable information including IP address and unique identifiers may be tracked to help serve you the content on the Platform better and keep track of any bugs that may occur. </p>

<p>We collect the following Information while you register with us: </p>

<p>Profile information like Your name, address, social media profile link, in the event you are using that to log onto the Platform  </p>

<p>Mobile no. </p>

<p>Email address </p>

<p>Device ID   </p>

<p>Any communication between You and Us.   </p>

 

<p>Other Information we collect are: </p>

<p>Location Information </p>

<p>Technical information with respect to the devices on which you are using our Services including the date and time at which you are using our Services, Your IP address and the type of browser being used. </p>

<p>Account  Information including purchase or redemption information, page-view and clicks information (including the videos which you have watched), your activities on our Platforms or other information about your interactions with businesses with which we operate co-branded offerings </p>

<p>We may also track certain Information based upon Your behavior, acts, subscriptions and preferences on Our Platform(s).  </p>

 

<p>HOW WE USE YOUR INFORMATION: </p>

 

<p>Your Information, including Personal Information is used to: </p>

<p>facilitate Your use of the Platform/Service and provide You with information about the Platform/Service; </p>

<p>provide You personalized content which may include advertisements; </p>

<p>remember Information so that You need not re-enter it during Your subsequent visits; </p>

<p>improve our Platforms and for internal research;  </p>

<p>fix technical problems, if any; </p>

<p>automatically update Our App on Your devices; </p>

<p>properly administer and protect the integrity of the Platform; </p>

<p>take and handle orders, deliver products and services, process payments, and communicate with you about orders, products, services, and promotional offers </p>

<p>monitor metrics such as total number of visitors, traffic, and demographic patterns; </p>

<p>comply with applicable law. </p>

<p>Your Information and information from tools like cookies, log files, and device identifiers and location data is shared with third-party service providers on need to know basis. </p>

<p>We may share any Information with others to help detect and prevent identity theft, fraud and other potentially illegal acts.  </p>

<p>We might process your Personal Information for additional purposes that are not mentioned here, but are compatible with the original purpose for which the data was gathered. We will inform you of any further processing of Your Information. </p>

<p>If We sell or otherwise transfer part or the whole of the Platform to another organization Your Information may be among the items sold or transferred for the sole purpose of continuing the operation of the Services and the Platform, and only if the recipient of the Personal Information commits to a privacy policy that has terms substantially consistent with this Policy. </p>

<p>We may disclose Your Information to the extent such disclosure is reasonably necessary to enforce Our Terms of Use or Our other policies and in order to respond to claims of any other user or third-party. </p>

 

<p>DISCLAIMERS: </p>

 

<p>6.1 Although We use industry standard practices to protect Your privacy, no method of transmission over the Internet, or method of electronic storage, is one hundred percent secure. Please contact us if You believe Your Information is compromised. If we learn of a security systems breach, we will inform You and the authorities of the occurrence of the breach in accordance with applicable law. </p>

<p>Your Information may be stored and processed in India or any other country in which We provide Services. </p>

<p>We use commercially reasonable safeguards to help keep the Information collected through the Platform secure and take reasonable steps (such as requesting a unique password) to verify Your identity before granting You access to Your account. However, We cannot ensure the security of any Information You transmit on the Platform or guarantee that Information on the Platform may not be accessed, disclosed, altered, or destroyed. </p>

<p>When You access Our Platform(s), We offer the use of a secure server. The secure server software (SSL) encrypts all Information You put in before it is sent to Us.</p>  

 

 

<p>COOKIES:  </p>

 

<p>We use "cookies" and “cache” (collectively, “Cookies”) on certain pages of the Platform to help analyse Our web page flow, measure promotional effectiveness, and to enhance Your experience on Our Platform only. A cookie is a tiny text file stored on your device which stores information and helps sites work. We do not use cookies to collect any of your personal information.   </p>

<p>We use cookies for the following purposes: </p>

<p>To log in which will not to collect any Information;</p> 

<p>To provide you personalized Services;</p> 

<p>To track the performance and use of our Platform;  </p>

 

<p>HOW LONG DO WE KEEP YOUR INFORMATION: </p>

 

<p>We may retain certain Personal Information, after Your account is deactivated, for a reasonable time for backup, archival, audit and/or legal purposes. </p>

<p>We may as we feel appropriate either delete Your Personal Information or de-identify it so that it is not attributed to You.  </p>

<p>You may contact Us for erasing Your Personal Information or for restriction of processing Your Information. </p>

 

<p>MISCELLANEOUS: </p>

 

<p>We do not knowingly collect any Information from children (persons aged below 18 years).  </p>

<p>In accordance with Information Technology Act 2000 and rules made there under, the name and contact details of the Grievance Officer are provided below: </p>

    <p>          Name: Aashiq Bava </p>

 <p>E-mail id: aashiq.saina@gmail.com </p>

 

<p>You may contact Us at sainavideo.com/about </p>

 

 
</div>
         
     </div>
</template>
<script>
export default {
    
}
</script>
<style>
p, h3{
    color:white;
}

@media screen and (max-width: 981px) {
    p,h3{
        font-size:45px;
    }
}
</style>
