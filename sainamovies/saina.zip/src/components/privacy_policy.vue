<template>
     <div id="bg" class="uk-width-1-1@m" style="background-color:black;width:-webkit-fill-available;">
         <router-link v-bind:to="'/movies'" >
            <img id="navimg" src="../assets/images/sainalogin1.png" style="width: 60px;margin-left:100px;margin-top:30px;" >
                <!-- <a id="navfont" style="color:darkorange;font-size:90px;text-decoration:none;" class="uk-text-capitalize "> Saina</a>   -->
        </router-link>
         <div class="uk-container uk-container-large uk-margin-large-left uk-margin-large-right uk-margin-large-top" style="padding-top:50px; padding-bottom:100px;background:#131311">
           
<h3>PRIVACY POLICY </h3>
 



 

<p>As updated on 26/12/2018 </p>

<p>Thank You for using Saina Video Vision, Our App, Saina Play, and/or Our Website, Sainavideo.com (“We” or “Us” or “Platform” as the case may be). This Privacy Policy (“Policy”) governs the use of Our Platform and the content appearing on Our Platform by all members of the Platform (“Users” or “You” or “Your”). These Terms should be read concurrently with our Terms of Use (the “Terms”). </p>

<p>DEFINITIONS: </p>

 

<p>“Information" shall mean any information You provide Us or give us access to in any form. E.g. your details while registering with us, the videos you viewed etc.  </p>

<p>“Personal Information” shall mean Information disclosed by or obtained from any user of the Platform(s) or by using the Services. e.g. age, any other personal details capable of identifying You. </p>

<p>Capitalized terms used here, which are not defined here will have the same definition as that used in the Terms. </p>

 

 

<p>PURPOSE OF THIS POLICY AND WHY WE COLLECT PERSONAL INFORMATION:  </p>

 

<p>Your privacy is important to Us. This Policy will familiarize You with the manner in which We collect, use and disclose Your Personal Information. Your Personal Information is collected to improve Your experience on the Platform and Services and to provide You Services which are specifically meant for You. We only collect information which is quite necessary for this purpose.  </p>

 

<p>AMENDMENTS: </p>

 

<p>We may modify this Policy at our discretion (“Amendments”) without prior notice to you. The modified Policy shall be updated on our Platform with the date of latest revision. You are requested to keep checking this Policy on the Platform to keep yourself abreast with the Amendments made.  </p>

 

<p>INFORMATION WE COLLECT: </p>

 

<p>You can browse the Platform without providing any Personal Information. However, other identifiable information including IP address and unique identifiers may be tracked to help serve you the content on the Platform better and keep track of any bugs that may occur. </p>

<p>We collect the following Information while you register with us: </p>

<p>Profile information like Your name, address, social media profile link, in the event you are using that to log onto the Platform  </p>

<p>Mobile no. </p>

<p>Email address </p>

<p>Device ID   </p>

<p>Any communication between You and Us.   </p>

 

<p>Other Information we collect are: </p>

<p>Location Information </p>

<p>Technical information with respect to the devices on which you are using our Services including the date and time at which you are using our Services, Your IP address and the type of browser being used. </p>

<p>Account  Information including purchase or redemption information, page-view and clicks information (including the videos which you have watched), your activities on our Platforms or other information about your interactions with businesses with which we operate co-branded offerings </p>

<p>We may also track certain Information based upon Your behavior, acts, subscriptions and preferences on Our Platform(s).  </p>

 

<p>HOW WE USE YOUR INFORMATION: </p>

 

<p>Your Information, including Personal Information is used to: </p>

<p>facilitate Your use of the Platform/Service and provide You with information about the Platform/Service; </p>

<p>provide You personalized content which may include advertisements; </p>

<p>remember Information so that You need not re-enter it during Your subsequent visits; </p>

<p>improve our Platforms and for internal research;  </p>

<p>fix technical problems, if any; </p>

<p>automatically update Our App on Your devices; </p>

<p>properly administer and protect the integrity of the Platform; </p>

<p>take and handle orders, deliver products and services, process payments, and communicate with you about orders, products, services, and promotional offers </p>

<p>monitor metrics such as total number of visitors, traffic, and demographic patterns; </p>

<p>comply with applicable law. </p>

<p>Your Information and information from tools like cookies, log files, and device identifiers and location data is shared with third-party service providers on need to know basis. </p>

<p>We may share any Information with others to help detect and prevent identity theft, fraud and other potentially illegal acts.  </p>

<p>We might process your Personal Information for additional purposes that are not mentioned here, but are compatible with the original purpose for which the data was gathered. We will inform you of any further processing of Your Information. </p>

<p>If We sell or otherwise transfer part or the whole of the Platform to another organization Your Information may be among the items sold or transferred for the sole purpose of continuing the operation of the Services and the Platform, and only if the recipient of the Personal Information commits to a privacy policy that has terms substantially consistent with this Policy. </p>

<p>We may disclose Your Information to the extent such disclosure is reasonably necessary to enforce Our Terms of Use or Our other policies and in order to respond to claims of any other user or third-party. </p>

 

<p>DISCLAIMERS: </p>

 

<p>6.1 Although We use industry standard practices to protect Your privacy, no method of transmission over the Internet, or method of electronic storage, is one hundred percent secure. Please contact us if You believe Your Information is compromised. If we learn of a security systems breach, we will inform You and the authorities of the occurrence of the breach in accordance with applicable law. </p>

<p>Your Information may be stored and processed in India or any other country in which We provide Services. </p>

<p>We use commercially reasonable safeguards to help keep the Information collected through the Platform secure and take reasonable steps (such as requesting a unique password) to verify Your identity before granting You access to Your account. However, We cannot ensure the security of any Information You transmit on the Platform or guarantee that Information on the Platform may not be accessed, disclosed, altered, or destroyed. </p>

<p>When You access Our Platform(s), We offer the use of a secure server. The secure server software (SSL) encrypts all Information You put in before it is sent to Us.</p>  

 

 

<p>COOKIES:  </p>

 

<p>We use "cookies" and “cache” (collectively, “Cookies”) on certain pages of the Platform to help analyse Our web page flow, measure promotional effectiveness, and to enhance Your experience on Our Platform only. A cookie is a tiny text file stored on your device which stores information and helps sites work. We do not use cookies to collect any of your personal information.   </p>

<p>We use cookies for the following purposes: </p>

<p>To log in which will not to collect any Information;</p> 

<p>To provide you personalized Services;</p> 

<p>To track the performance and use of our Platform;  </p>

 

<p>HOW LONG DO WE KEEP YOUR INFORMATION: </p>

 

<p>We may retain certain Personal Information, after Your account is deactivated, for a reasonable time for backup, archival, audit and/or legal purposes. </p>

<p>We may as we feel appropriate either delete Your Personal Information or de-identify it so that it is not attributed to You.  </p>

<p>You may contact Us for erasing Your Personal Information or for restriction of processing Your Information. </p>

 

<p>MISCELLANEOUS: </p>

 

<p>We do not knowingly collect any Information from children (persons aged below 18 years).  </p>

<p>In accordance with Information Technology Act 2000 and rules made there under, the name and contact details of the Grievance Officer are provided below: </p>

    <p>          Name: Aashiq Bava </p>

 <p>E-mail id: aashiq.saina@gmail.com </p>

 

<p>You may contact Us at sainavideo.com/about </p>

 

 
</div>
         
     </div>
</template>
<script>
export default {
    
}
</script>
<style>
p, h3{
    color:white;
}
@media screen and (max-width: 981px) {
    p,h3{
        font-size:45px;
    }
}
</style>
