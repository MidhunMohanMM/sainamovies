<template>
    <div id="bg" class="uk-width-1-1@m" style="background-color:black;height:-webkit-fill-available;width:-webkit-fill-available;">
        <!-- <img src="../assets/images/dark.jpg" alt=""> -->
        <div class="uk-position-center" >
            <img src="../assets/images/sainalogin.png" alt="" class="uk-align-center uk-margin-large-bottom" style="width: 135px;" id="lmi">
            <button id="lmf" @click="FBLogin()" class="uk-button uk-button-primary" style="background-color: transparent;width:120px;background-color: #3a5695;margin-left:90px;"><i class="fab fa-facebook-f" ></i></button>
            <br><br>
            <div id="google-signin-btn" class="g-signin2 lmg" data-onsuccess="onSignIn" data-theme="dark" style="margin-left:90px;"></div>
            <br><br><br><br> 
            <router-link v-bind:to="'/movies'">
                <button class="uk-button uk-button-default" @click="guest()" style="background-color:#7a868b;width:300px; height: 39px;color:white;margin-top:30px;border-color:transparent">SKIP</button>
            </router-link>
            <br>
        </div>
        <!-- <div class="uk-position-center" >
            <img src="../assets/images/sainalogin.png" alt="" class="uk-align-center uk-margin-large-bottom" style="width: 30%;" id="lmi">
            <button id="lmf" @click="FBLogin()" class="uk-button uk-button-primary uk-align-center" style="background-color: transparent;width:60%;padding:3%;background-color: #3a5695;"><i class="fab fa-facebook-f" ></i></button>
            <br><br>
            <div id="google-signin-btn" class="g-signin2 lmg" data-onsuccess="onSignIn" data-theme="dark" style="margin-left:90px;"></div>
            <br><br><br><br> 
            <router-link v-bind:to="'/movies'">
                <button class="uk-button uk-button-default" @click="guest()" style="background-color:#7a868b;width:300px; height: 39px;color:white;margin-top:30px;border-color:transparent">SKIP</button>
            </router-link>
            <br>
        </div> -->
    </div>
</template>

<script>

import Vue from 'vue'
import facebookLogin from 'facebook-login-vuejs';

export default {
    data(){
        return {
            name: "",
            banners: [],
            popularmovies: [],
            trendingmovies: [],
            newmovies: [],
            slide: 0,
            rating: "",
            sliding: null,
            payload: "",
            ID : "",
            accessToken: "",
            sub: {
                grant_type: "convert_token",    
                backend: "google_oauth2", 
                client_id: "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7", 
                token: ""
            }
        }
    },
    components: {
        facebookLogin
    },
    mounted(){
        this.gethome();
        gapi.signin2.render('google-signin-btn', { // this is the button "id"
            onsuccess: this.onSignIn // note, no "()" here
        })
        $('#signinButton').click(function() {
            auth2.grantOfflineAccess().then(signInCallback);
        });
    },
    methods:{
        guest(){
            var self = this;
            localStorage.setItem('Name', 'Guest' );
            self.$router.replace({ name: "home" });
        },
        gethome(){
            var self = this;
            axios.get('https://app.sainavideo.com//vdocipher/api/home/',{
            })
            .then(function(response){
                //console.log(response.data);  
                self.banners = response.data.banner;
                self.features = response.data.feature;

                for(var i=0;i<response.data.feature.length;i++){
                //console.log(self.features[i].movie);
                }   

                self.newmovies = self.features[0].movie;
                self.popularmovies = self.features[1].movie;
                self.trendingmovies = self.features[2].movie;
                
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });
        },
        onSignIn(googleUser) {
            var self = this;
             var profile = googleUser.getBasicProfile();
    
            localStorage.setItem('Name', profile.getGivenName() );
            // The ID token you need to pass to your backend:
            var id_token = googleUser.getAuthResponse().id_token;
            var token = gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse().id_token;
            var GoogleAuth = gapi.auth2.getAuthInstance();
            
            var access_token = GoogleAuth.currentUser.Ab.Zi.access_token
            localStorage.setItem('access_token', access_token );
            //console.log("hi");
            self.$router.replace({ name: "home" });
        },
        FBLogin(){
            var self = this;
            FB.login(function(response) {
                if (response.authResponse) {
                ////console.log('Welcome!  Fetching your information.... ');
                FB.api('/me', function(response) {
                ////console.log('Good to see you, ' + response.name + '.');
                ////console.log(response);
                self.accessToken = FB.getAuthResponse().accessToken;
                ////console.log(self.accessToken);
                self.sub.token = self.accessToken;
                self.sub.backend = "facebook";
                ////console.log(self.sub);
                self.convert();
                    // axios.post('https://app.sainavideo.com/auth/convert-token/',self.sub)
                    // .then(function(response){

                    //     ////console.log(response.data);  
                    //      self.$router.replace({ name: "home" });                               
                    // })
                    // .catch(function (error) {
                    //     ////console.log('An Error occured',  error);
                    // });
                });
                } else {
                ////console.log('User cancelled login or did not fully authorize.');
                }
            });
        },
        convert(){
            var self = this;    
            self.sub.token = self.accessToken;
            ////console.log(self.sub);
                axios.post('https://app.sainavideo.com/auth/convert-token',self.sub)
                .then(function(response){
                    ////console.log(response.data);                            
                })
                .catch(function (error) {
                    ////console.log('An Error occured',  error);
                });
        },
    }
}
</script>
<style scoped>
@media (max-width: 1020px) {
     /* #lmi{
        width: 0%!important;
    } */
    /*#lmf{
        width: 50%!important;
        margin-left: 250px!important;
    }
    .lmg{
        width: 50%!important;
    } */
}

</style>
