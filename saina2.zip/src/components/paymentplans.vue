<template>
    <div>
        <img src="../assets/images/dark.jpg" alt="">
        <div class="uk-padding-large uk-position-center">
            <h3 style="color:white;" class="uk-text-bold">SAINA PREMIUM</h3>
            <h5 style="color:white;">All Malayalam movies and TV shows</h5>
            <button @click="myFunction1()" id="btn1" class="uk-button uk-button-default  uk-margin-large-top" style="width:400px;color:white;background:rgb(93, 42, 33);border-color:transparent">₹10 per day</button>
            <br>
            <button @click="myFunction2()" id="btn2" class="uk-button uk-button-default  uk-margin-top" style="width:400px;color:white;background:rgb(93, 42, 33);border-color:transparent">₹999 per year</button>
            <br>
            <button @click="myFunction3()" id="btn3" class="uk-button uk-button-default  uk-margin-top" style="width:400px;color:white;background:rgb(93, 42, 33);border-color:transparent">₹199 per month</button>
            <br><br>
            <div id="myDIV" style="display:none;">
                <form  id="payment-form">
                    <div class="form-row">
                        <h5 style="color:white;">Credit or debit card</h5>
                        <div id="card-element">
                        <!-- A Stripe Element will be inserted here. -->
                        </div>
                        <!-- Used to display form errors. -->
                        <div id="card-errors" role="alert"></div>
                    </div>
                    <br>
                    <button  class="uk-button uk-button-default " style="color:white;background:rgb(93, 42, 33);border-color:transparent">Submit Payment</button>
                </form>
            </div>
        </div>   
        <nav id="ft" class="uk-navbar-container" uk-navbar style="background:rgb(122, 134, 139);height:43px;">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav uk-margin-large-left">
                        <li class="uk-text-small" style="color:white;"> Saina Movies © All Rights Reserved</li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav uk-margin-left">
                        <li class="uk-text-small" style="color:white; padding-right:30px;" >Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Terms of use</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:70px;">Privacy Policy</li>
                    </ul>
                </div>
            </nav>
    </div>
</template>



<script>
export default {
    data(){
        return{
            datas:[],
            sub:{
                plan: "",
                token:""
            },
            subr: {
                grant_type: "refresh_token",
                client_id: "",
                refresh_token: ""
            },
             subup: {
                plan: ""
            },
        }
    },
    mounted(){
        this.getPaymentPlans();
        this.tokenrefresh();
    },
    methods: {
        tokenrefresh(){
            var self = this;
            self.subr.client_id =  "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7";
            self.subr.refresh_token =  localStorage.getItem('refresh_token');
            ////console.log(self.subr);
            axios.post('https://app.sainavideo.com/auth/token/',self.subr)
            .then(function(response){

                ////console.log(response.data);  
                localStorage.setItem('server_access_token', response.data.access_token);       
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });
        },
        getPaymentPlans(){
            var self = this;
            // Create a Stripe client.
            var stripe = Stripe('pk_test_pZIuKEO2ZXnwL8q6XT5BgbKj');
            
            // Create an instance of Elements.
            var elements = stripe.elements();
            
            // Custom styling can be passed to options when creating an Element.
            // (Note that this demo uses a wider set of styles than the guide below.)
            var style = {
                base: {
                    color: '#32325d',
                    lineHeight: '18px',
                    fontFamily: '"Raleway", Helvetica, sans-serif',
                    fontSmoothing: 'antialiased',
                    fontSize: '16px',
                    '::placeholder': {
                    color: '#aab7c4'
                    }
                },
                invalid: {
                    color: '#fa755a',
                    iconColor: '#fa755a'
                }
            };
        
            // Create an instance of the card Element.
            var card = elements.create('card', {style: style});
            
            // Add an instance of the card Element into the `card-element` <div>.
            card.mount('#card-element');
            
            // Handle real-time validation errors from the card Element.
            card.addEventListener('change', function(event) {
                var displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });
        
            // Handle form submission.
            var form = document.getElementById('payment-form');
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                
                stripe.createToken(card).then(function(result) {
                    if (result.error) {
                        // Inform the user if there was an error.
                        var errorElement = document.getElementById('card-errors');
                        errorElement.textContent = result.error.message;
                    } else {
                        // Send the token to your server.
                        stripeTokenHandler(result.token);
                    }
                });
            });
        
            // Submit the form with the token ID.
            function stripeTokenHandler(token) {
                // Insert the token ID into the form so it gets submitted to the server
                var form = document.getElementById('payment-form');
                var hiddenInput = document.createElement('input');
                hiddenInput.setAttribute('type', 'hidden');
                hiddenInput.setAttribute('name', 'stripeToken');
                hiddenInput.setAttribute('value', token.id);
                form.appendChild(hiddenInput);
                
                // Submit the form
                ////console.log(token.id);
                // var self = this;
                self.sub.token = token.id;
                //  console
                ////console.log(self.sub);
                var server_access_token = localStorage.getItem('server_access_token');
                ////console.log(server_access_token);
                // axios.get('https://app.sainavideo.com/auth/token')
                // .then(function(response){

                //     ////console.log(response.data);  
                //     alert("Congratulations! You are now a premium member !");
                //     self.$router.replace({ name: "movieplay" });
                // //  self.datas = response.data.data;
                            
                // })
                // .catch(function (error) {
                //     ////console.log('An Error occured',  error);
                // });
                var product_id = localStorage.getItem('product_id');
                if(product_id== ''){
                    axios.post('https://app.sainavideo.com/vdocipher/api/subscribe/',self.sub,{
                        headers: {'Authorization': 'Bearer '+server_access_token},              
                    })
                    .then(function(response){
                        ////console.log(response.data);  
                        alert("Congratulations! You are now a premium member !");
                        self.$router.replace({ name: "movieplay" });              
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                }
                else{
                    var server_access_token = localStorage.getItem('server_access_token')
                    self.subup.plan = product_id;
                    axios.post('https://app.sainavideo.com/vdocipher/api/updatesub/',self.subup,{
                        headers: {'Authorization': 'Bearer '+server_access_token},
                    })
                    .then(function(response){
                        ////console.log(response.data);  
                        if(response.data.status == true){
                            alert("Payment updated");
                        }
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                }
                

            }
        },
        myFunction1() {
            var self = this;
            self.sub.plan = 'DAILYPLAN';
            var x = document.getElementById("myDIV");
            var property1 = document.getElementById("btn1");
            var property2 = document.getElementById("btn2");
            var property3 = document.getElementById("btn3");
            x.style.display = "block";
            property1.style.backgroundColor = "rgb(178, 134, 87)";
            property2.style.backgroundColor = "rgb(93, 42, 33)";
            property3.style.backgroundColor = "rgb(93, 42, 33)";
        },
        myFunction2() {
            var self = this;
            self.sub.plan = 'plan_DkNcPqPK9pJaRp';
            var x = document.getElementById("myDIV");
            var property1 = document.getElementById("btn1");
            var property2 = document.getElementById("btn2");
            var property3 = document.getElementById("btn3");
            x.style.display = "block";
            property1.style.backgroundColor = "rgb(93, 42, 33)";
            property2.style.backgroundColor = "rgb(178, 134, 87)";
            property3.style.backgroundColor = "rgb(93, 42, 33)";
        },
        myFunction3() {
            var self = this;
            self.sub.plan = 'plan_DkNb3kQwIDTiIe';
            var x = document.getElementById("myDIV");
            var property1 = document.getElementById("btn1");
            var property2 = document.getElementById("btn2");
            var property3 = document.getElementById("btn3");
            x.style.display = "block";
            property1.style.backgroundColor = "rgb(93, 42, 33)";
            property2.style.backgroundColor = "rgb(93, 42, 33)";
            property3.style.backgroundColor = "rgb(178, 134, 87)";
        }
    }
}

</script>

<style scoped>
.navbar-logo {
    width: 90px;
}
.StripeElement {
    background-color: white;
    height: 18px;
    padding: 10px 12px;
    border-radius: 4px;
    border: 1px solid #ccd0d2;
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: box-shadow 150ms ease;
    transition: box-shadow 150ms ease;
}

.StripeElement--focus {
    box-shadow: 0 1px 3px 0 #cfd7df;
}

.StripeElement--invalid {
    border-color: #fa755a;
}

.StripeElement--webkit-autofill {
    background-color: #fefde5 !important;
}

#card-colors {
    color: #fa755a;
}
</style>