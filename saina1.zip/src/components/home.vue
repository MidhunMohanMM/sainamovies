<template>
    <html>
        <div style="background:black;">
            <nav class="uk-navbar-container" uk-navbar style="background:black;height:50px;">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav">
                        <li ><router-link v-bind:to="'/profile'" uk-icon="user"></router-link></li>
                        <li ><router-link v-bind:to="'/profile'">{{ name }}</router-link></li>
                    </ul>
                </div>
                <div class="uk-navbar-center">
                    <ul class="uk-navbar-nav">    
                        <li><router-link v-bind:to="'/movies'"><a style="color:darkorange;font-size:30px;text-decoration:none" class="uk-text-capitalize">Saina</a>   </router-link></li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <div>
                        <a class="uk-navbar-toggle" uk-search-icon href="#"></a>
                        <div class="uk-drop"  uk-drop="mode: click; pos: left-center; offset: 0">
                            <form class="uk-search uk-search-navbar uk-width-1-1">
                                <input style="color:white;" v-on:input="search" v-on:focus="search" v-model="srch" class="uk-search-input" type="search" placeholder="Search..." autofocus>
                                <div uk-dropdown="animation: uk-animation-slide-top-small; duration: 1000" v-if="srch!= ''"  style="background:black;margin-top:0px;">
                                    <ul v-for="searchResult in searchResults"  :key="searchResult.id" v-if="!noResults" class="uk-nav uk-dropdown-nav" >
                                        <li  class="uk-active">
                                            <a style="color:white;" href="#">{{ searchResult.title }}</a>
                                        
                                        </li>
                                    </ul>
                                    <ul v-if="noResults" class="uk-nav uk-dropdown-nav">
                                        <li>
                                            <a style="color:white;" href="#">No Results found</a>
                                        </li>
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </nav>
            <div id="slideshow" uk-slideshow="animation: push;min-height: 300; max-height: 400;autoplay: true" >
                <div class="uk-position-relative uk-visible-toggle uk-light">
                    <ul class="uk-slideshow-items">
                        <li v-for="movie in banners" :key="movie.id">
                            <router-link v-bind:to="'/movies/'+movie.title.title+'/'+movie.title.id_v">
                                <div class="uk-position-cover  uk-animation-reverse uk-transform-origin-center-left">
                                    <img :src="movie.image" alt="" uk-cover style="margin-top:70vh">
                                </div>
                                <div class="uk-overlay uk-overlay-primary uk-position-bottom uk-text-center uk-transition-slide-bottom">
                                    <h3 class="uk-margin-remove">{{movie.title.title}}</h3>                        
                                </div>
                            </router-link>
                        </li>
                        <li v-for="feature in slider" :key="feature.id">
                            <router-link v-bind:to="'/movies/'+feature.title+'/'+feature.id_v">
                                <div class="uk-position-cover  uk-animation-reverse uk-transform-origin-center-left">
                                    <img :src="feature.poster_image" alt="" uk-cover >
                                </div>
                                <div class="uk-overlay uk-overlay-primary uk-position-bottom uk-text-center uk-transition-slide-bottom">
                                    <h3 class="uk-margin-remove">{{feature.title}}</h3>                        
                                </div>
                            </router-link>
                        </li>
                    </ul>
                    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>
                    <a   class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>
                </div>
                <ul class="uk-slideshow-nav uk-dotnav uk-flex-center uk-margin"></ul>
            </div>
            <router-link v-bind:to="'/category/popular'">
                <p id="category" style="padding-top:30px;color:white;padding-left:10px;padding-bottom:20px;text-decoration:inherit">POPULAR MOVIES ></p>
            </router-link>
            <div id="pplr">
                <div class="uk-position-relative uk-visible-toggle uk-light " uk-slider="sets: true;autoplay: true">
                    <ul id="pul" class="uk-slider-items uk-child-width-1-2 uk-child-width-1-5@m " style="width:1073px;">
                        <li  v-for="movie in popularmovies" :key="movie.id">                       
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null">
                                                <div v-if="movie.rating=='5.00'" class="text">Rating: 5/5</div>
                                                <div v-if="movie.rating=='4.50'" class="text">Rating: 4.5/5</div>
                                                <div v-if="movie.rating=='4.00'" class="text">Rating: 4/5</div>
                                                <div v-if="movie.rating=='3.50'" class="text">Rating: 3.5/5</div>
                                                <div v-if="movie.rating=='3.00'" class="text">Rating: 3/5</div>
                                                <div v-if="movie.rating=='2.50'" class="text">Rating: 2.5/5</div>
                                                <div v-if="movie.rating=='2.00'" class="text">Rating: 2/5</div>
                                                <div v-if="movie.rating=='1.50'" class="text">Rating: 1.5/5</div>
                                                <div v-if="movie.rating=='1.00'" class="text">Rating: 1/5</div>
                                                <div v-if="movie.rating=='0.50'" class="text">Rating: 0.5/5</div>
                                                <div v-if="movie.rating=='0.00'" class="text">Rating: 0/5</div>
                                            </div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div>             
                        </li>
                    </ul>
                    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                    <a style="color:red;" class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>
                </div>
            </div>

            <div id="pplrm"  class="uk-container uk-container-large uk-margin-large-top uk-margin-large-bottom">
                    <div uk-grid >
                        <div v-for="movie in popularmovies" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>



            <router-link v-bind:to="'/category/trending'">
                <p style="color:white;padding-left:10px;padding-top:20px;padding-bottom:20px;text-decoration:inherit">TRENDING ></p>
            </router-link>
            <div id="pplr"  class="uk-position-relative uk-visible-toggle uk-light" uk-slider="sets: true;autoplay: true">
                <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-5@m"  style="width:1073px;">
                    <li  v-for="movie in trendingmovies" :key="movie.id">     
                        <div class="uk-text-center">
                            <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">              
                                    <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                    <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                        <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                        <div v-if="movie.rating!=null">
                                            <div v-if="movie.rating=='5.00'" class="text">Rating: 5/5</div>
                                            <div v-if="movie.rating=='4.50'" class="text">Rating: 4.5/5</div>
                                            <div v-if="movie.rating=='4.00'" class="text">Rating: 4/5</div>
                                            <div v-if="movie.rating=='3.50'" class="text">Rating: 3.5/5</div>
                                            <div v-if="movie.rating=='3.00'" class="text">Rating: 3/5</div>
                                            <div v-if="movie.rating=='2.50'" class="text">Rating: 2.5/5</div>
                                            <div v-if="movie.rating=='2.00'" class="text">Rating: 2/5</div>
                                            <div v-if="movie.rating=='1.50'" class="text">Rating: 1.5/5</div>
                                            <div v-if="movie.rating=='1.00'" class="text">Rating: 1/5</div>
                                            <div v-if="movie.rating=='0.50'" class="text">Rating: 0.5/5</div>
                                            <div v-if="movie.rating=='0.00'" class="text">Rating: 0/5</div>
                                        </div>                      
                                    </div>
                                </div>
                            </router-link>
                            <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>  
                        </div>  
                    </li>
                </ul>
                <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>
            </div>

            <div id="pplrm"  class="uk-container uk-container-large uk-margin-large-top uk-margin-large-bottom">
                    <div  uk-grid >
                        <div v-for="movie in trendingmovies" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>


            <router-link v-bind:to="'/category/new'">
                <p style="color:white;padding-left:10px;;padding-top:20px;padding-bottom:20px;text-decoration:inherit">NEW RELEASES ></p>
            </router-link>
            <div id="pplr"  class="uk-position-relative uk-visible-toggle uk-light" uk-slider="sets: true;autoplay: true" style="padding-bottom:60px;">
                <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-5@m" style="width:1073px;">
                    <li  v-for="movie in newmovies" :key="movie.id">          
                        <div class="uk-text-center">
                            <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                   
                                    <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null">
                                                <div v-if="movie.rating=='5.00'" class="text">Rating: 5/5</div>
                                                <div v-if="movie.rating=='4.50'" class="text">Rating: 4.5/5</div>
                                                <div v-if="movie.rating=='4.00'" class="text">Rating: 4/5</div>
                                                <div v-if="movie.rating=='3.50'" class="text">Rating: 3.5/5</div>
                                                <div v-if="movie.rating=='3.00'" class="text">Rating: 3/5</div>
                                                <div v-if="movie.rating=='2.50'" class="text">Rating: 2.5/5</div>
                                                <div v-if="movie.rating=='2.00'" class="text">Rating: 2/5</div>
                                                <div v-if="movie.rating=='1.50'" class="text">Rating: 1.5/5</div>
                                                <div v-if="movie.rating=='1.00'" class="text">Rating: 1/5</div>
                                                <div v-if="movie.rating=='0.50'" class="text">Rating: 0.5/5</div>
                                                <div v-if="movie.rating=='0.00'" class="text">Rating: 0/5</div>
                                            </div>                           
                                        </div>
                                </div>
                            </router-link>
                            <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>      
                        </div>
                    </li>
                </ul>
                <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>
            </div>

            <div id="pplrm"  class="uk-container uk-container-large uk-margin-large-top uk-margin-large-bottom">
                    <div uk-grid >
                        <div v-for="movie in trendingmovies" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>


            <nav id="ft" class="uk-navbar-container" uk-navbar style="background:rgb(122, 134, 139);height:43px;">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav uk-margin-large-left">
                        <li class="uk-text-small" style="color:white;"> Saina Movies © All Rights Reserved</li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav uk-margin-left">
                        <li class="uk-text-small" style="color:white; padding-right:30px;" >Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Terms of use</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:70px;">Privacy Policy</li>
                    </ul>
                </div>
            </nav>
        </div>
    </html>
</template>

<script>
import Vue from 'vue';
import qs from 'qs';
var querystring = require('querystring');
export default {
    data(){
        return{
            srch: "",
            name: "",
            banners: [],
            popularmovies: [],
            searchResults: [],
            trendingmovies: [],
            newmovies: [],
            noResults: "",
            slide: 0,
            rating: "",
            sliding: null,
            accessToken: "",
            sub: {
                'grant_type': 'convert_token',    
                'backend': 'google-oauth2', 
                'client_id': 'QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7', 
                'token': ''
            },
            subr: {
                grant_type: "refresh_token",
                client_id: "",
                refresh_token: ""
            }
        }
    },
    mounted(){
        var self = this;
        this.gethome();
        this.tokenrefresh();
        this.slider();
        this.convert();
        self.name =  localStorage.getItem('Name');
    },
    methods: {
         tokenrefresh(){
            var self = this;
            self.subr.client_id =  "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7";
            self.subr.refresh_token =  localStorage.getItem('refresh_token');
        
            axios.post('https://app.sainavideo.com/auth/token/',self.subr)
            .then(function(response){

             
                localStorage.setItem('server_access_token', response.data.access_token);       
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
        },
        search(){
            var self = this;
          
            axios.get('https://app.sainavideo.com/vdocipher/api/search/?keyword='+self.srch,{
            })
            .then(function(response){
                   
                self.searchResults = response.data.results;
               
                self.noResults = self.searchResults.length === 0;                       
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
        },
        onSlideStart (slide) {
        this.sliding = true
        },
        slider(){
            var self = this;
            axios.get('https://app.sainavideo.com/vdocipher/api/webhome/',{
            })
                .then(function(response){
                   
                    self.features1 = response.data.feature;
                   
                    self.slider = self.features1[2].movie;
                  
                })
                .catch(function (error) {
                    //console.log('An Error occured',  error);
                });
        },
        convert(){
            var name = localStorage.getItem('Name');
            if(name!='Guest'){
            var self = this;
            var access_token = localStorage.getItem('access_token');
            self.sub.token = access_token;
          
            const requestBody = querystring.stringify({
                grant_type: 'convert_token',    
                backend: 'google_oauth2',
                client_id: 'QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7',
                token: 'ya29.GlxiBpUfID9Ys_cv_aQl4NDH9UWi65E9lsiUvuU2DQwhx1hUCgJkc4Sfgj2atNy4yZ5htS24HG6BqOmaApp4AxbUUk0AgHNcxpriYum8HiW3GlUoyQbsby8OLOviYA',
            });

            const config = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
             

            axios.post('https://app.sainavideo.com/auth/convert-token/',self.sub)
            .then(function(response){

              
                    localStorage.setItem('server_access_token', response.data.access_token);
                    localStorage.setItem('refresh_token', response.data.refresh_token);
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
            }
        },
        gethome(){
            var self = this;      
            axios.get('https://app.sainavideo.com//vdocipher/api/home/')
            .then(function(response){
              
                self.banners = response.data.banner;
                self.features = response.data.feature;
               
                self.newmovies = self.features[0].movie;
                self.popularmovies = self.features[1].movie;
                self.trendingmovies = self.features[2].movie;     
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });        
        },
        onSlideEnd (slide) {
            this.sliding = false
        }
    } 
}
</script>



<style scoped>
.navbar-logo {
  width: 50px;
}


.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.5;
}

.container:hover .middle {
  opacity: 1;

}

.text {
  background-color: black;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
}
#category{
    text-decoration:none
}
/* #slideshow{
    display:none;
} */

@media screen and (max-width: 980px) {
    #slideshow{
        display:none!important;
    }
    #pplr{
        display:none;
    }
}

@media screen and (min-width: 981px) {

  #pplrm{
        display:none;
    }

}


</style>