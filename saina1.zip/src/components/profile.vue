<template>
    <div>
        <nav class="uk-navbar-container" uk-navbar style="background:black;height:50px;">
            <div class="uk-navbar-left">
                <ul class="uk-navbar-nav">
                    <li ><router-link v-bind:to="'/profile'" uk-icon="user"></router-link></li>
                    <li ><router-link v-bind:to="'/profile'">{{ name }}</router-link></li>
                </ul>
            </div>
            <div class="uk-navbar-center">
                <ul class="uk-navbar-nav">    
                    <li><router-link v-bind:to="'/movies'"><a style="color:darkorange;font-size:30px;text-decoration:none" class="uk-text-capitalize">Saina</a>   </router-link></li>
                </ul>
            </div>
            <div class="uk-navbar-right">
                <div>
                    <a class="uk-navbar-toggle" uk-search-icon href="#"></a>
                    <div class="uk-drop"  uk-drop="mode: click; pos: left-center; offset: 0">
                        <form class="uk-search uk-search-navbar uk-width-1-1">
                            <input style="color:white;" v-on:input="search" v-on:focus="search" v-model="srch" class="uk-search-input" type="search" placeholder="Search..." autofocus>
                            <div uk-dropdown="animation: uk-animation-slide-top-small; duration: 1000" v-if="srch!= ''"  style="background:black;margin-top:0px;">
                                <ul v-for="searchResult in searchResults"  :key="searchResult.id" v-if="!noResults" class="uk-nav uk-dropdown-nav" >
                                    <li  class="uk-active">
                                        <a style="color:white;" href="#">{{ searchResult.title }}</a>
                                    
                                    </li>
                                </ul>
                                <ul v-if="noResults" class="uk-nav uk-dropdown-nav">
                                    <li>
                                        <a style="color:white;" href="#">No Results found</a>
                                    </li>
                                </ul>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </nav>
        <div class="uk-container uk-container-small uk-margin-large-top uk-margin-large-bottom" style="background:#fbfbfb">
            <div>
                <p class="uk-text-large uk-margin-top">Account</p>
                <hr class="uk-divider-icon">
                <div>
                    <p class="uk-align-left">Membership</p>               
                    <div class="uk-align-right uk-margin-large-right">
                        <p v-if="me.user_plan == 'DAILY'">Daily Plan</p>
                        <p v-if="me.user_plan == 'Yearly Plan'">Yearly Plan</p>
                        <p v-if="me.user_plan == 'Monthly Plan'">Monthly Plan</p>
                        <hr>
                        <p >Subscription Valid Till: {{ me.expiry_date }}</p>
                        <a @click="update()">Update Subscription</a><br><br>
                        <a @click="cancel()">Cancel Subscription</a><br><br>
                        <p>Account Details</p>
                        <hr>
                        <p> {{ me.email }}</p>
                        <a @click="logout()">Sign out from all devices</a>
                    </div>       
                </div>
                <br><br><br><br>
                <div class="uk-thumbnav uk-thumbnav-vertical" uk-margin>
                    <img src="../assets/images/a1.png" width="100" alt="">
                    <p>{{ me.user }}</p>
                </div>
            </div>
            <p style="padding-left:10px;padding-top:140px;padding-bottom:20px;">Watchlist</p>
            <p style="padding-left:10px;" v-if="noResults1"> No Bookmarked movies</p>
            <div class="uk-position-relative uk-visible-toggle uk-light uk-margin-large-bottom" uk-slider="sets: true;autoplay: true">
                <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-5@m"  style="width:1073px;">
                    <li v-for="movie in list" :key="movie.id" style="padding-right:10px;">     
                        <div class="uk-text-center">
                            <button @click="deletewatchlist(movie.id)" style="color:black" class="uk-align-right" type="button" uk-close></button>
                            <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                                                
                                    <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.poster_image" alt="">
                                </div>
                            </router-link>
                            <p v-if="movie.title!=null" class="uk-margin-top" style="color:black;">{{ movie.title }}</p>  
                        </div>  
                    </li>
                </ul>
                <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>
            </div>
            
        </div>
        <nav class="uk-navbar-container" uk-navbar style="background:rgb(122, 134, 139);height:43px;">
            <div class="uk-navbar-left">
                <ul class="uk-navbar-nav uk-margin-large-left">
                    <li style="color:white;"> Saina Movies © All Rights Reserved</li>
                </ul>
            </div>
            <div class="uk-navbar-right">
                <ul class="uk-navbar-nav uk-margin-left">
                    <li style="color:white; padding-right:30px;" >Help</li>
                    <li style="color:white;padding-right:30px;">Terms of use</li>
                    <li style="color:white;padding-right:30px;">Help</li>
                    <li style="color:white;padding-right:70px;">Privacy Policy</li>
                </ul>
            </div>
        </nav>
    </div>
</template>
<script>
export default {
    data(){
        return{
            srch: "",
            noResults: "",
            noResults1: "",
            plan: "",
            name: "",
            me: "",
            list: "",
            subid: {
                bookmark_id: ""
            },
            subup: {
                plan: ""
            },
            subr: {
                grant_type: "refresh_token",
                client_id: "",
                refresh_token: ""
            }
        }
    },
 
    mounted(){
        this.userdetails();
        this.watchlist();
        this.tokenrefresh();
       // this.cancel();
        this.name =  localStorage.getItem('Name');
        if(this.name == 'Guest')
            this.$router.replace({ name: "home"});
    },
    methods: {
        tokenrefresh(){
            var self = this;
            self.subr.client_id =  "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7";
            self.subr.refresh_token =  localStorage.getItem('refresh_token');
            //console.log(self.subr);

            //axios({url: 'https://app.sainavideo.com/auth/token/', data:self.subr, method: 'POST' })

            axios.post('https://app.sainavideo.com/auth/token/',self.subr)
            .then(function(response){

                //console.log(response.data);  
                localStorage.setItem('server_access_token', response.data.access_token);       
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
        },
        logout() {
            document.location.href = "https://www.google.com/accounts/Logout?continue=https://appengine.google.com/_ah/logout?continue=http://localhost:6886/movies";
        },
        search(){
            var self = this;
            //console.log(self.srch);
            axios.get('https://app.sainavideo.com/vdocipher/api/search/?keyword='+self.srch,{
            })
            .then(function(response){
                //console.log(response.data);           
                self.searchResults = response.data.results;
                //console.log(self.searchResults);
                self.noResults = self.searchResults.length === 0;                       
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
        },
        update(){
            var self = this;
            localStorage.setItem('product_id', self.me.product_id);
            this.$router.replace ({ name: "paymentplans" });
            // var server_access_token = localStorage.getItem('server_access_token')
            // //console.log(self.me.product_id);
            // self.subup.plan = self.me.product_id;
            // axios.post('https://app.sainavideo.com/vdocipher/api/updatesub/',self.subup,{
            //      headers: {'Authorization': 'Bearer '+server_access_token},
            // })
            //     .then(function(response){
            //         //console.log(response.data);  
            //     })
            //     .catch(function (error) {
            //         //console.log('An Error occured',  error);
            //     });
        },
        cancel(){
            var self = this;
            var server_access_token1 = localStorage.getItem('server_access_token');
            //console.log(server_access_token1);
            // axios.post('https://app.sainavideo.com/vdocipher/api/cancelsub/',{
            //      headers: {'Authorization': 'Bearer '+server_access_token1}
            // })

            axios({url: 'https://app.sainavideo.com/vdocipher/api/cancelsub', method: 'POST',headers: {'Authorization': 'Bearer '+server_access_token1} })
                .then(function(response){
                    //console.log(response.data);  
                })
                .catch(function (error) {
                    //console.log('An Error occured',  error.response);
                });
        },
        signout(){
            localStorage.clear();
            this.$router.replace( { name: "login" });
        },
        userdetails(){
            var self = this;
            var server_access_token = localStorage.getItem('server_access_token');
            //console.log(server_access_token)
            axios.get('https://app.sainavideo.com/vdocipher/api/me/',{
                 headers: {'Authorization': 'Bearer '+server_access_token},
            })
            .then(function(response){
                //console.log(response.data); 
                self.me = response.data.me;
             //   //console.log(response.data.me.user_plan);
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
        },
        watchlist(){
            var self = this;
            var server_access_token = localStorage.getItem('server_access_token');
            //console.log(server_access_token);
            axios.get('https://app.sainavideo.com/vdocipher/api/watchlist',{
                 headers: {'Authorization': 'Bearer '+server_access_token},
            })
            .then(function(response){
                //console.log(response.data); 
                self.list = response.data.results;
                self.noResults1 = self.list.length === 0;  
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
        },
        deletewatchlist(id){
            var self = this;
            var server_access_token = localStorage.getItem('server_access_token');
            //console.log(server_access_token);
            //console.log(id);
            self.subid.bookmark_id = id;
            axios.post('https://app.sainavideo.com/vdocipher/api/deletewatchlist',self.subid,{
            headers: {'Authorization': 'Bearer '+server_access_token}
            })
            .then(function(response){
                //console.log(response.data);    
                this.watchlist();           
            })
            .catch(function (error) {
                //console.log('An Error occured',  error);
            });
        }
    }
}
</script>
<style scoped>

</style>