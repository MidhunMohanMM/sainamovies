<template>
    <html>
        <span id="load" ></span>
        <div id="contents">
        <div style="background: url(https://img.yts.am/assets/images/movies/the_predator_2018/background.jpg) no-repeat center center; background-size: cover; -webkit-background-size: cover;-moz-background-size: cover; -o-background-size: cover;">
            <nav class="uk-navbar-container" uk-navbar style="background:black;height:50px;">
                 
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav">
                        <li><a class="uk-navbar-toggle uk-hidden@l" uk-navbar-toggle-icon href="#" type="button" uk-toggle="target: #offcanvas-push"></a></li>
                        <li><router-link v-bind:to="'/movies'">
                            <img src="../assets/images/sainalogin1.png" style="width: 15px;margin-right:10px;margin-left:30px;">
                                <a style="color:darkorange;font-size:27px;text-decoration:none" class="uk-text-capitalize"> Saina</a>  
                            </router-link>
                        </li>

                    </ul>
                </div>

        <div id="offcanvas-push" uk-offcanvas="mode: push; overlay: true">
         <div class="uk-offcanvas-bar uk-flex uk-flex-column">
            <button class="uk-offcanvas-close" type="button" uk-close></button>
            <ul class="uk-nav uk-nav-primary uk-nav-center uk-margin-auto-vertical" uk-nav="multiple: true">
                
                <img class="uk-border-circle" width="80" height="80" src="../assets/images/a1.png">
                <!-- <li><router-link v-bind:to="'/movies'"><a style="color:darkorange;font-size:30px;text-decoration:none" class="uk-text-capitalize">Saina</a>   </router-link></li> -->
               <li class="uk-nav-header uk-text-capitalize uk-text-large" onTranslate="global.menu.title">{{ name }}</li>
               <li class=" uk-text-lowercase " onTranslate="global.menu.subtitle">{{ email }}</li>
               <li class="uk-divider-icon uk-margin-remove-bottom"></li>
               <li>
                  <a ><router-link v-bind:to="'/profile'"><span uk-icon="user"></span> My Account</router-link></a>
               </li>
               <!-- <li class="uk-parent">
                  <a>News</a>
                  
               </li> -->
               <li class="uk-parent">
                  <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="heart"></span> My Watchlist</a>

               </li>
               <li class="uk-parent">
                  <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="commenting"></span> Help</a>

               </li>
               <li class="uk-parent">
                  <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="info"></span> Terms of Use</a>

               </li>

               <li>
                  <a class="uk-nav-header uk-text-capitalize" href='#'><span uk-icon="list"></span> Privacy Policy</a>
               </li>
               <li>
                  <a class="uk-nav-header uk-text-capitalize" @click="logout()"><span uk-icon="sign-out"></span> Log Out</a>
               </li>
    
               <hr class="uk-nav-divider">
            </ul>
         </div>
      </div>


  
                  <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav">
                        <li>
                             <a class="uk-navbar-toggle" uk-search-icon href="#"></a>
                        <div class="uk-drop"  uk-drop="mode: click; pos: left-center; offset: 0">
                            <form class="uk-search uk-search-navbar uk-width-1-1">
                                <input style="color:white;" v-on:input="search" v-on:focus="search" v-model="srch" class="uk-search-input" type="search" placeholder="Search..." autofocus>
                                <div uk-dropdown="animation: uk-animation-slide-top-small; duration: 1000" v-if="srch!= ''"  style="background:black;margin-top:0px;">
                                    <ul v-for="searchResult in searchResults"  :key="searchResult.id" v-if="!noResults" class="uk-nav uk-dropdown-nav" >
                                        <li  class="uk-active">
                                            <a style="color:white;" href="#">{{ searchResult.title }}</a>
                                        
                                        </li>
                                    </ul>
                                    <ul v-if="noResults" class="uk-nav uk-dropdown-nav">
                                        <li>
                                            <a style="color:white;" href="#">No Results found</a>
                                        </li>
                                    </ul>
                                </div>
                            </form>
                        </div>
                        </li>
                         <li><a class="uk-navbar-toggle uk-hidden@l" uk-navbar-toggle-icon href="#" type="button" uk-toggle="target: #offcanvas-push"></a></li>
                        <li ><router-link v-bind:to="'/profile'" uk-icon="user"></router-link></li>
                        <li ><router-link v-bind:to="'/profile'" class="uk-text-capitalize">Welcome {{ name }}!</router-link></li>
                    </ul>
                </div>
            </nav>
            <div id="slideshow" uk-slideshow="animation: push;min-height: 300; max-height: 400;autoplay: true" >
                <div class="uk-position-relative uk-visible-toggle uk-light">
                    <ul class="uk-slideshow-items" >
                        <li v-for="movie in banners" :key="movie.id" >
                            <router-link v-bind:to="'/movies/'+movie.title.title+'/'+movie.title.id_v" >
                                <div class="uk-position-cover  uk-animation-reverse uk-transform-origin-center-left" >
                                    <img :src="movie.image" alt="" uk-cover style="margin-top:70vh">
                                </div>
                                <div class="uk-overlay uk-overlay-primary uk-position-bottom uk-text-center uk-transition-slide-bottom">
                                    <h3 class="uk-margin-remove">{{movie.title.title}}</h3>                        
                                </div>
                            </router-link>
                        </li>
                        <li v-for="feature in slider" :key="feature.id">
                            <router-link v-bind:to="'/movies/'+feature.title+'/'+feature.id_v">
                                <div class="uk-position-cover  uk-animation-reverse uk-transform-origin-center-left">
                                    <img :src="feature.poster_image" alt="" uk-cover >
                                </div>
                                <div class="uk-overlay uk-overlay-primary uk-position-bottom uk-text-center uk-transition-slide-bottom">
                                    <h3 class="uk-margin-remove">{{feature.title}}</h3>                        
                                </div>
                            </router-link>
                        </li>
                    </ul>
                    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>
                    <a   class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>
                </div>
                <ul class="uk-slideshow-nav uk-dotnav uk-flex-center uk-margin"></ul>
            </div>
            <router-link v-bind:to="'/category/popular'">
                <div id="category"  style="padding-top:2%;color:white;padding-left:1%;text-decoration:inherit"><p class="uk-align-left"> POPULAR MOVIES > </p><p class="uk-align-right" style="margin-right:1%">VIEW ALL</p></div>
            </router-link>
            

            <div id="pplr"  class="uk-container uk-container-large uk-margin-large-top uk-margin-bottom">
                    <div class="uk-child-width-1-6" uk-grid >
                        <div v-for="movie in popularmovies.slice(0, 6)" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                         <div class="middle">
                                             
                                            <div v-if="movie.skills.tags!=''" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v+'/watch'">
                                                <button class="uk-button uk-button-small uk-button-default " style="background:rgb(205, 116, 0);border:none!important;color:white;width:100%">Play now</button>
                                            </router-link>
                                            <div v-if="movie.rating!=null">
                                                <div v-if="movie.rating=='5.00'" class="text">Rating: 5/5</div>
                                                <div v-if="movie.rating=='4.50'" class="text">Rating: 4.5/5</div>
                                                <div v-if="movie.rating=='4.00'" class="text">Rating: 4/5</div>
                                                <div v-if="movie.rating=='3.50'" class="text">Rating: 3.5/5</div>
                                                <div v-if="movie.rating=='3.00'" class="text">Rating: 3/5</div>
                                                <div v-if="movie.rating=='2.50'" class="text">Rating: 2.5/5</div>
                                                <div v-if="movie.rating=='2.00'" class="text">Rating: 2/5</div>
                                                <div v-if="movie.rating=='1.50'" class="text">Rating: 1.5/5</div>
                                                <div v-if="movie.rating=='1.00'" class="text">Rating: 1/5</div>
                                                <div v-if="movie.rating=='0.50'" class="text">Rating: 0.5/5</div>
                                                <div v-if="movie.rating=='0.00'" class="text">Rating: 0/5</div>

                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>

            <div id="pplrm"  class="uk-container uk-container-large uk-margin-large-top uk-margin-bottom">
                    <div class="uk-child-width-1-3" uk-grid >
                        <div v-for="movie in popularmovies" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div class="middle">
                                            <div v-if="movie.skills.tags!=''" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null">
                                                <div v-if="movie.rating=='5.00'" class="text">Rating: 5/5</div>
                                                <div v-if="movie.rating=='4.50'" class="text">Rating: 4.5/5</div>
                                                <div v-if="movie.rating=='4.00'" class="text">Rating: 4/5</div>
                                                <div v-if="movie.rating=='3.50'" class="text">Rating: 3.5/5</div>
                                                <div v-if="movie.rating=='3.00'" class="text">Rating: 3/5</div>
                                                <div v-if="movie.rating=='2.50'" class="text">Rating: 2.5/5</div>
                                                <div v-if="movie.rating=='2.00'" class="text">Rating: 2/5</div>
                                                <div v-if="movie.rating=='1.50'" class="text">Rating: 1.5/5</div>
                                                <div v-if="movie.rating=='1.00'" class="text">Rating: 1/5</div>
                                                <div v-if="movie.rating=='0.50'" class="text">Rating: 0.5/5</div>
                                                <div v-if="movie.rating=='0.00'" class="text">Rating: 0/5</div>
                                            </div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>


            <router-link v-bind:to="'/category/trending'">
                <div id="category"  style="padding-top:1%;color:white;padding-left:1%;text-decoration:inherit"><p class="uk-align-left">TRENDING > </p><p class="uk-align-right" style="margin-right:1%">VIEW ALL</p></div>
            </router-link>
            <!-- <router-link v-bind:to="'/category/trending'">
                <p style="color:white;padding-left:10px;padding-top:20px;padding-bottom:20px;text-decoration:inherit">TRENDING ></p>
            </router-link> -->
            <div id="pplr"  class="uk-container uk-container-large uk-margin-large-top uk-margin-bottom">
                    <div class="uk-child-width-1-6" uk-grid >
                        <div v-for="movie in trendingmovies.slice(0, 6)" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                         <div class="middle">
                                             
                                            <div v-if="movie.skills.tags!=''" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v+'/watch'">
                                                <button class="uk-button uk-button-small uk-button-default " style="background:rgb(205, 116, 0);border:none!important;color:white;width:100%">Play now</button>
                                            </router-link>
                                            <div v-if="movie.rating!=null">
                                                <div v-if="movie.rating=='5.00'" class="text">Rating: 5/5</div>
                                                <div v-if="movie.rating=='4.50'" class="text">Rating: 4.5/5</div>
                                                <div v-if="movie.rating=='4.00'" class="text">Rating: 4/5</div>
                                                <div v-if="movie.rating=='3.50'" class="text">Rating: 3.5/5</div>
                                                <div v-if="movie.rating=='3.00'" class="text">Rating: 3/5</div>
                                                <div v-if="movie.rating=='2.50'" class="text">Rating: 2.5/5</div>
                                                <div v-if="movie.rating=='2.00'" class="text">Rating: 2/5</div>
                                                <div v-if="movie.rating=='1.50'" class="text">Rating: 1.5/5</div>
                                                <div v-if="movie.rating=='1.00'" class="text">Rating: 1/5</div>
                                                <div v-if="movie.rating=='0.50'" class="text">Rating: 0.5/5</div>
                                                <div v-if="movie.rating=='0.00'" class="text">Rating: 0/5</div>

                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>

            <div id="pplrm"  class="uk-container uk-container-large uk-margin-large-top uk-margin-bottom">
                    <div class="uk-child-width-1-3" uk-grid >
                        <div v-for="movie in trendingmovies" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div class="middle">
                                            <div v-if="movie.skills.tags!=''" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>


            <!-- <router-link v-bind:to="'/category/new'">
                <p style="color:white;padding-left:10px;;padding-top:20px;padding-bottom:20px;text-decoration:inherit">NEW RELEASES ></p>
            </router-link> -->
            <router-link v-bind:to="'/category/new'">
                <div id="category"  style="padding-top:2%;color:white;padding-left:1%;text-decoration:inherit"><p class="uk-align-left">NEW MOVIES> </p><p class="uk-align-right" style="margin-right:1%">VIEW ALL</p></div>
            </router-link>
        <div id="pplr"  class="uk-container uk-container-large uk-margin-large-top uk-margin-bottom">
                    <div class="uk-child-width-1-6" uk-grid >
                        <div v-for="movie in newmovies.slice(0, 6)" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                         <div class="middle">
                                             
                                            <div v-if="movie.skills.tags!=''" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v+'/watch'">
                                                <button class="uk-button uk-button-small uk-button-default " style="background:rgb(205, 116, 0);border:none!important;color:white;width:100%">Play now</button>
                                            </router-link>
                                            <div v-if="movie.rating!=null">
                                                <div v-if="movie.rating=='5.00'" class="text">Rating: 5/5</div>
                                                <div v-if="movie.rating=='4.50'" class="text">Rating: 4.5/5</div>
                                                <div v-if="movie.rating=='4.00'" class="text">Rating: 4/5</div>
                                                <div v-if="movie.rating=='3.50'" class="text">Rating: 3.5/5</div>
                                                <div v-if="movie.rating=='3.00'" class="text">Rating: 3/5</div>
                                                <div v-if="movie.rating=='2.50'" class="text">Rating: 2.5/5</div>
                                                <div v-if="movie.rating=='2.00'" class="text">Rating: 2/5</div>
                                                <div v-if="movie.rating=='1.50'" class="text">Rating: 1.5/5</div>
                                                <div v-if="movie.rating=='1.00'" class="text">Rating: 1/5</div>
                                                <div v-if="movie.rating=='0.50'" class="text">Rating: 0.5/5</div>
                                                <div v-if="movie.rating=='0.00'" class="text">Rating: 0/5</div>

                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>

            <div id="pplrm"  class="uk-container uk-container-large uk-margin-large-top uk-margin-bottom">
                    <div class="uk-child-width-1-3 uk-margin-large-top" uk-grid >
                        <div v-for="movie in trendingmovies" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div class="middle">
                                            <div v-if="movie.skills.tags!=''" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>


            <nav id="ft" class="uk-navbar-container" uk-navbar style="background:rgb(122, 134, 139);height:43px;">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav uk-margin-large-left">
                        <li class="uk-text-small" style="color:white;"> Saina Movies © All Rights Reserved</li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav uk-margin-left">
                        <li class="uk-text-small" style="color:white; padding-right:30px;" >Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Terms of use</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:70px;">Privacy Policy</li>
                    </ul>
                </div>
            </nav>
        </div>
        </div>
    </html>
</template>

<script>
import Vue from 'vue';
import qs from 'qs';
var querystring = require('querystring');
export default {
    data(){
        return{
            srch: "",
            name: "",
            email: "",
            banners: [],
            popularmovies: [],
            searchResults: [],
            trendingmovies: [],
            newmovies: [],
            noResults: "",
            slide: 0,
            rating: "",
            sliding: null,
            accessToken: "",
            sub: {
                'grant_type': 'convert_token',    
                'backend': 'google-oauth2', 
                'client_id': 'QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7', 
                'token': ''
            },
            subr: {
                grant_type: "refresh_token",
                client_id: "",
                refresh_token: ""
            }
        }
    },
    mounted(){
        var self = this;
        this.gethome();
        this.tokenrefresh();
        this.slider();
        this.convert();
        self.name =  localStorage.getItem('Name');
        self.email =  localStorage.getItem('Email');
        this.loader();
    },
    methods: {
         loader(){
            $('#load').show(1).delay(1000).hide(1);
        },
         tokenrefresh(){
            var self = this;

            var started = localStorage['started'];
            if (started) {

                var diff = Date.now() - started;

                if (diff >= 1000 ) {
                    self.subr.client_id =  "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7";
                    self.subr.refresh_token =  localStorage.getItem('refresh_token');
                
                    axios.post('https://app.sainavideo.com/auth/token/',self.subr)
                    .then(function(response){
                      //  console.log(response.data);
                    
                        localStorage.setItem('server_access_token', response.data.access_token);       
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                }
            }
             else {
                localStorage['started'] = Date.now();
            }
                  
        },
        search(){
            var self = this;
          
            axios.get('https://app.sainavideo.com/vdocipher/api/search/?keyword='+self.srch,{
            })
            .then(function(response){
                   
                self.searchResults = response.data.results;
               
                self.noResults = self.searchResults.length === 0;                       
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });
        },
        onSlideStart (slide) {
        this.sliding = true
        },
        slider(){
            var self = this;
            axios.get('https://app.sainavideo.com/vdocipher/api/webhome/',{
            })
                .then(function(response){
                   
                    self.features1 = response.data.feature;
                   
                    self.slider = self.features1[2].movie;
                  
                })
                .catch(function (error) {
                    ////console.log('An Error occured',  error);
                });
        },
        logout() {
            document.location.href = "https://www.google.com/accounts/Logout?continue=https://appengine.google.com/_ah/logout?continue=https://sainavideo.com";
        },
        convert(){
            var name = localStorage.getItem('Name');
            if(name!='Guest'){
            var self = this;
            var access_token = localStorage.getItem('access_token');
            self.sub.token = access_token;
          
            const requestBody = querystring.stringify({
                grant_type: 'convert_token',    
                backend: 'google_oauth2',
                client_id: 'QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7',
                token: 'ya29.GlxiBpUfID9Ys_cv_aQl4NDH9UWi65E9lsiUvuU2DQwhx1hUCgJkc4Sfgj2atNy4yZ5htS24HG6BqOmaApp4AxbUUk0AgHNcxpriYum8HiW3GlUoyQbsby8OLOviYA',
            });

            const config = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
             

            axios.post('https://app.sainavideo.com/auth/convert-token/',self.sub)
            .then(function(response){

              
                    localStorage.setItem('server_access_token', response.data.access_token);
                    localStorage.setItem('refresh_token', response.data.refresh_token);
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });
            }
        },
        gethome(){
            var self = this;      
            axios.get('https://app.sainavideo.com//vdocipher/api/home/')
            .then(function(response){

              //  console.log(response.data);
              
                self.banners = response.data.banner;
                self.features = response.data.feature;
               
                self.newmovies = self.features[0].movie;
                self.popularmovies = self.features[1].movie;
                self.trendingmovies = self.features[2].movie;     
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });        
        },
        onSlideEnd (slide) {
            this.sliding = false
        }
    } 
}
</script>



<style scoped>
.navbar-logo {
  width: 50px;
}


.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.5;
}

.container:hover .middle {
  opacity: 1;

}

.text {
  background-color: black;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
  /* padding: 14px 26px; */
}

.btn {
  padding: 0px 26px;
}
#category{
    text-decoration:none
}
/* #slideshow{
    display:none;
} */

@media screen and (max-width: 980px) {
    #slideshow{
        display:none!important;
    }
    #pplr{
        display:none;
    }
}

@media screen and (min-width: 981px) {

  #pplrm{
        display:none;
    }

}

a {
    text-decoration: none;
    }
        #load{
    width:100%;
    height:100%;
    position:fixed;
    z-index:9999;
    background:url("../assets/images/803 (4).gif") no-repeat center center;
}
</style>