<template>
    <div id="bg" class="uk-width-1-1@m" style="background-color:black;background-image:linear-gradient(to right, rgba(100,0,0,0), rgba(100,0,0,1));height:-webkit-fill-available;width:-webkit-fill-available;">
        <!-- <img src="../assets/images/dark.jpg" alt=""> -->
                <span id="load" ></span>
        <div id="contents">
        <div style="background: url(https://img.yts.am/assets/images/movies/the_predator_2018/background.jpg) no-repeat center center; background-size: cover; -webkit-background-size: cover;-moz-background-size: cover; -o-background-size: cover;">
            <nav class="uk-navbar-container" uk-navbar style="background:black;height:50px;">
                 
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav">
                        <li style="width: 5%;padding-top: 3%;padding-left: 2%;"><button @click="back"  style="z-index:+1;background-color: transparent; border: none;"><img src="../assets/images/back.png" style="padding-top: 33%;"></button></li>
                        <li><a class="uk-navbar-toggle uk-hidden@l" uk-navbar-toggle-icon href="#" type="button" uk-toggle="target: #offcanvas-push"></a></li>
                        <li><router-link v-bind:to="'/movies'">
                            <img src="../assets/images/sainalogin1.png" style="width: 15px;margin-right:10px;margin-left:30px;">
                                <a style="color:darkorange;font-size:27px;text-decoration:none" class="uk-text-capitalize"> Saina</a>  
                            </router-link>
                        </li>
                        <!-- <li ><router-link v-bind:to="'/profile'" uk-icon="user"></router-link></li>
                        <li ><router-link v-bind:to="'/profile'">{{ name }}</router-link></li> -->
                    </ul>
                </div>

        <div id="offcanvas-push" uk-offcanvas="mode: push; overlay: true">
         <div class="uk-offcanvas-bar uk-flex uk-flex-column">
            <button class="uk-offcanvas-close" type="button" uk-close></button>
            <ul class="uk-nav uk-nav-primary uk-nav-center uk-margin-auto-vertical" uk-nav="multiple: true">
                
                <img class="uk-border-circle" width="80" height="80" src="../assets/images/a1.png">
                <!-- <li><router-link v-bind:to="'/movies'"><a style="color:darkorange;font-size:30px;text-decoration:none" class="uk-text-capitalize">Saina</a>   </router-link></li> -->
               <li class="uk-nav-header uk-text-capitalize uk-text-large" onTranslate="global.menu.title">{{ name }}</li>
               <li class=" uk-text-lowercase " onTranslate="global.menu.subtitle">{{ email }}</li>
               <li class="uk-divider-icon uk-margin-remove-bottom"></li>
               <li>
                  <a ><router-link v-bind:to="'/profile'"><span uk-icon="user"></span> My Account</router-link></a>
               </li>
               <!-- <li class="uk-parent">
                  <a>News</a>
                  
               </li> -->
               <li class="uk-parent">
                  <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="heart"></span> My Watchlist</a>

               </li>
               <li class="uk-parent">
                  <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="commenting"></span> Help</a>

               </li>
               <li class="uk-parent">
                  <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="info"></span> Terms of Use</a>

               </li>

               <li>
                  <a class="uk-nav-header uk-text-capitalize" href='#'><span uk-icon="list"></span> Privacy Policy</a>
               </li>
               <li>
                  <a class="uk-nav-header uk-text-capitalize" @click="logout()"><span uk-icon="sign-out"></span> Log Out</a>
               </li>
    
               <hr class="uk-nav-divider">
            </ul>
         </div>
      </div>


                <!-- <div class="uk-navbar-center">
                    <ul class="uk-navbar-nav">    
                        <li><router-link v-bind:to="'/movies'"><a style="color:darkorange;font-size:30px;text-decoration:none" class="uk-text-capitalize">Saina</a>   </router-link></li>
                    </ul>
                </div> -->
                  <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav">
                        <li>
                             <a class="uk-navbar-toggle" uk-search-icon href="#"></a>
                        <div class="uk-drop"  uk-drop="mode: click; pos: left-center; offset: 0">
                            <form class="uk-search uk-search-navbar uk-width-1-1">
                                <input style="color:white;" v-on:input="search" v-on:focus="search" v-model="srch" class="uk-search-input" type="search" placeholder="Search..." autofocus>
                                <div uk-dropdown="animation: uk-animation-slide-top-small; duration: 1000" v-if="srch!= ''"  style="background:black;margin-top:0px;">
                                    <ul v-for="searchResult in searchResults"  :key="searchResult.id" v-if="!noResults" class="uk-nav uk-dropdown-nav" >
                                        <li  class="uk-active">
                                            <a style="color:white;" href="#">{{ searchResult.title }}</a>
                                        
                                        </li>
                                    </ul>
                                    <ul v-if="noResults" class="uk-nav uk-dropdown-nav">
                                        <li>
                                            <a style="color:white;" href="#">No Results found</a>
                                        </li>
                                    </ul>
                                </div>
                            </form>
                        </div>
                        </li>
                         <li><a class="uk-navbar-toggle uk-hidden@l" uk-navbar-toggle-icon href="#" type="button" uk-toggle="target: #offcanvas-push"></a></li>
                        <li ><router-link v-bind:to="'/profile'" uk-icon="user"></router-link></li>
                        <li ><router-link v-bind:to="'/profile'" class="uk-text-capitalize">Welcome {{ name }}!</router-link></li>
                    </ul>
                </div>
            </nav>
        </div>
        </div>
        <div class="uk-padding-large uk-position-center">
            <h3 style="color:white;" class="uk-text-bold">SAINA PREMIUM</h3>
            <h5 style="color:white;">All Malayalam movies and TV shows</h5>
            <button @click="myFunction1()" id="btn1" class="uk-button uk-button-default  uk-margin-large-top" style="width:400px;color:white;background:rgb(93, 42, 33);border-color:transparent">₹10 per day</button>
            <br>
            <button @click="myFunction2()" id="btn2" class="uk-button uk-button-default  uk-margin-top" style="width:400px;color:white;background:rgb(93, 42, 33);border-color:transparent">₹999 per year</button>
            <br>
            <button @click="myFunction3()" id="btn3" class="uk-button uk-button-default  uk-margin-top" style="width:400px;color:white;background:rgb(93, 42, 33);border-color:transparent">₹199 per month</button>
            <br><br>
            <div id="myDIV" style="display:none;">
                <form  id="payment-form">
                    <div class="form-row">
                        <h5 style="color:white;">Credit or debit card</h5>
                        <div id="card-element" >
                        <!-- A Stripe Element will be inserted here. -->
                        </div>
                        <!-- Used to display form errors. -->
                        <div id="card-errors" role="alert"></div>
                    </div>
                    <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
                    <label style="color:white;"><input class="uk-checkbox" type="checkbox" style="color:white;" > I agree to terms and conditions</label>
                    </div>
                    <br>
                    <button  class="uk-button uk-button-default " style="color:white;background:rgb(93, 42, 33);border-color:transparent">Submit Payment</button>
                    
                </form>
            </div>
        </div>   
    </div>
</template>



<script>
export default {
    data(){
        return{
            datas:[],
            name: "",
            email: "",
            sub:{
                plan: "",
                token:""
            },
            subr: {
                grant_type: "refresh_token",
                client_id: "",
                refresh_token: ""
            },
             subup: {
                plan: ""
            },
            srch: ""
        }
    },
    mounted(){
        this.getPaymentPlans();
        this.tokenrefresh();
        this.loader();
        this.name =  localStorage.getItem('Name');
        this.email =  localStorage.getItem('Email');
    },
    methods: {
          search(){
            var self = this;
            ////console.log(self.srch);
            axios.get('https://app.sainavideo.com/vdocipher/api/search/?keyword='+self.srch,{
            })
            .then(function(response){

                ////console.log(response.data);  
            
                self.searchResults = response.data.results;
            ////console.log(self.searchResults);
            self.noResults = self.searchResults.length === 0;
                        
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });
    },
       tokenrefresh(){
            var self = this;

            var started = localStorage['started'];
            if (started) {

                var diff = Date.now() - started;

                if (diff >= 1000 ) {
                    self.subr.client_id =  "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7";
                    self.subr.refresh_token =  localStorage.getItem('refresh_token');
                
                    axios.post('https://app.sainavideo.com/auth/token/',self.subr)
                    .then(function(response){
                     //   console.log(response.data);
                    
                        localStorage.setItem('server_access_token', response.data.access_token);       
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                }
            }
             else {
                localStorage['started'] = Date.now();
            }
                  
        },
         loader(){
            $('#load').show(1).delay(1000).hide(1);
        },
        getPaymentPlans(){
            var self = this;
            // Create a Stripe client.
            var stripe = Stripe('pk_test_pZIuKEO2ZXnwL8q6XT5BgbKj');
            
            // Create an instance of Elements.
            var elements = stripe.elements();
            
            // Custom styling can be passed to options when creating an Element.
            // (Note that this demo uses a wider set of styles than the guide below.)
            var style = {
                base: {
                    color: '#32325d',
                    lineHeight: '18px',
                    fontFamily: '"Raleway", Helvetica, sans-serif',
                    fontSmoothing: 'antialiased',
                    fontSize: '16px',
                    '::placeholder': {
                    color: '#aab7c4'
                    }
                },
                invalid: {
                    color: '#fa755a',
                    iconColor: '#fa755a'
                }
            };
        
            // Create an instance of the card Element.
            var card = elements.create('card', {
                style: style,
                hidePostalCode : true
            });
            
            // Add an instance of the card Element into the `card-element` <div>.
            card.mount('#card-element');
            
            // Handle real-time validation errors from the card Element.
            card.addEventListener('change', function(event) {
                var displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });
        
            // Handle form submission.
            var form = document.getElementById('payment-form');
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                
                stripe.createToken(card).then(function(result) {
                    if (result.error) {
                        // Inform the user if there was an error.
                        var errorElement = document.getElementById('card-errors');
                        errorElement.textContent = result.error.message;
                    } else {
                        // Send the token to your server.
                        stripeTokenHandler(result.token);
                    }
                });
            });
        
            // Submit the form with the token ID.
            function stripeTokenHandler(token) {
                // Insert the token ID into the form so it gets submitted to the server
                var form = document.getElementById('payment-form');
                var hiddenInput = document.createElement('input');
                hiddenInput.setAttribute('type', 'hidden');
                hiddenInput.setAttribute('name', 'stripeToken');
                hiddenInput.setAttribute('value', token.id);
                form.appendChild(hiddenInput);
                
                self.sub.token = token.id;

                var server_access_token = localStorage.getItem('server_access_token');
                var product_id = localStorage.getItem('product_id');
                if(product_id== ''){
                    axios.post('https://app.sainavideo.com/vdocipher/api/subscribe/',self.sub,{
                        headers: {'Authorization': 'Bearer '+server_access_token},              
                    })
                    .then(function(response){
                        ////console.log(response.data);  
                        alert("Congratulations! You are now a premium member !");
                        self.$router.replace({ name: "movieplay" });              
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                }
                else{
                    var server_access_token = localStorage.getItem('server_access_token')
                    self.subup.plan = product_id;
                    axios.post('https://app.sainavideo.com/vdocipher/api/updatesub/',self.subup,{
                        headers: {'Authorization': 'Bearer '+server_access_token},
                    })
                    .then(function(response){
                        ////console.log(response.data);  
                        if(response.data.status == true){
                            alert("Payment updated");
                        }
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                }
                

            }
        },
        back(){
            var self = this;
            self.$router.replace ({ name: "home"});
        },
        myFunction1() {
            var self = this;
            self.sub.plan = 'DAILYPLAN';
            var x = document.getElementById("myDIV");
            var property1 = document.getElementById("btn1");
            var property2 = document.getElementById("btn2");
            var property3 = document.getElementById("btn3");
            x.style.display = "block";
            property1.style.backgroundColor = "rgb(178, 134, 87)";
            property2.style.backgroundColor = "rgb(93, 42, 33)";
            property3.style.backgroundColor = "rgb(93, 42, 33)";
        },
        myFunction2() {
            var self = this;
            self.sub.plan = 'plan_DkNcPqPK9pJaRp';
            var x = document.getElementById("myDIV");
            var property1 = document.getElementById("btn1");
            var property2 = document.getElementById("btn2");
            var property3 = document.getElementById("btn3");
            x.style.display = "block";
            property1.style.backgroundColor = "rgb(93, 42, 33)";
            property2.style.backgroundColor = "rgb(178, 134, 87)";
            property3.style.backgroundColor = "rgb(93, 42, 33)";
        },
        myFunction3() {
            var self = this;
            self.sub.plan = 'plan_DkNb3kQwIDTiIe';
            var x = document.getElementById("myDIV");
            var property1 = document.getElementById("btn1");
            var property2 = document.getElementById("btn2");
            var property3 = document.getElementById("btn3");
            x.style.display = "block";
            property1.style.backgroundColor = "rgb(93, 42, 33)";
            property2.style.backgroundColor = "rgb(93, 42, 33)";
            property3.style.backgroundColor = "rgb(178, 134, 87)";
        }
    }
}

</script>

<style scoped>
.navbar-logo {
    width: 90px;
}
.StripeElement {
    background-color: white;
    height: 18px;
    padding: 10px 12px;
    border-radius: 4px;
    border: 1px solid #ccd0d2;
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: box-shadow 150ms ease;
    transition: box-shadow 150ms ease;
}

.StripeElement--focus {
    box-shadow: 0 1px 3px 0 #cfd7df;
}

.StripeElement--invalid {
    border-color: #fa755a;
}

.StripeElement--webkit-autofill {
    background-color: #fefde5 !important;
}

#card-colors {
    color: #fa755a;
}

#load{
    width:100%;
    height:100%;
    position:fixed;
    z-index:9999;
    background:url("../assets/images/803 (4).gif") no-repeat center center;
}
img:hover {
    cursor: pointer;
}
</style>