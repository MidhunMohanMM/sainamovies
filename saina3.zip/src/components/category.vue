<template>
        <div style="background:#272727;">
            <nav class="uk-navbar-container" uk-navbar style="background:black;height:50px;">
                <div class="uk-navbar-left">
                     <ul class="uk-navbar-nav">
                         <li><a class="uk-navbar-toggle uk-hidden@l" uk-navbar-toggle-icon href="#" type="button" uk-toggle="target: #offcanvas-push"></a></li>
                        <li ><router-link v-bind:to="'/profile'" uk-icon="user"></router-link></li>
                        <li ><router-link v-bind:to="'/profile'">{{ name1 }}</router-link></li>
                    </ul>
                </div>
                <div id="offcanvas-push" uk-offcanvas="mode: push; overlay: true">
                    <div class="uk-offcanvas-bar uk-flex uk-flex-column">
                        <button class="uk-offcanvas-close" type="button" uk-close></button>
                        <ul class="uk-nav uk-nav-primary uk-nav-center uk-margin-auto-vertical" uk-nav="multiple: true">
                            <img class="uk-border-circle" width="80" height="80" src="../assets/images/a1.png">
                        <li class="uk-nav-header uk-text-capitalize uk-text-large" onTranslate="global.menu.title">{{ name }}</li>
                        <li class=" uk-text-lowercase " onTranslate="global.menu.subtitle">{{ email }}</li>
                        <li class="uk-divider-icon uk-margin-remove-bottom"></li>
                        <li>
                            <a ><router-link v-bind:to="'/profile'"><span uk-icon="user"></span> My Account</router-link></a>
                        </li>
                        <!-- <li class="uk-parent">
                            <a>News</a>
                            
                        </li> -->
                        <li class="uk-parent">
                            <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="heart"></span> My Watchlist</a>

                        </li>
                        <li class="uk-parent">
                            <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="commenting"></span> Help</a>

                        </li>
                        <li class="uk-parent">
                            <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="info"></span> Terms of Use</a>

                        </li>

                        <li>
                            <a class="uk-nav-header uk-text-capitalize" href='#'><span uk-icon="list"></span> Privacy Policy</a>
                        </li>
                        <li>
                            <a class="uk-nav-header uk-text-capitalize" @click="logout()"><span uk-icon="sign-out"></span> Log Out</a>
                        </li>
                
                        <hr class="uk-nav-divider">
                        </ul>
                    </div>
                </div>
                <div class="uk-navbar-center">
                    <ul class="uk-navbar-nav">
                        <li ><router-link v-bind:to="'/movies'"><a  style="color:darkorange;font-size:30px;text-decoration:none;" class="uk-text-capitalize">Saina</a></router-link></li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <div>
                        <a class="uk-navbar-toggle" uk-search-icon href="#"></a>
                        <div class="uk-drop"  uk-drop="mode: click; pos: left-center; offset: 0">
                            <form class="uk-search uk-search-navbar uk-width-1-1">
                                <input style="color:white;" v-on:input="search" v-on:focus="search" v-model="srch" class="uk-search-input" type="search" placeholder="Search..." autofocus>
                                <div uk-dropdown="animation: uk-animation-slide-top-small; duration: 1000" v-if="srch!= ''"  style="background:black;margin-top:0px;">
                                    <ul v-for="searchResult in searchResults"  :key="searchResult.id" v-if="!noResults" class="uk-nav uk-dropdown-nav" >
                                        <li  class="uk-active">
                                            <a style="color:#dc7b00;" href="#">{{ searchResult.title }}</a>                           
                                        </li>
                                    </ul>
                                    <ul  v-if="noResults" class="uk-nav uk-dropdown-nav">
                                        <li >
                                            <a style="color:white;" href="#">No Results found</a>
                                        </li>
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </nav>
            <div class="uk-margin-large-top">
                <p v-if="movname!=''" class="uk-text-center uk-text-large" style="color:white;">{{ movname }}</p> 
                <!-- <ul class="uk-pagination uk-flex-center" uk-margin>
                    <li><a href="#"><span uk-pagination-previous></span></a></li>
                    <li><a href="#">1</a></li>
                    <li class="uk-disabled"><span>...</span></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">6</a></li>
                    <li class="uk-active"><span>7</span></li>
                    <li><a href="#">8</a></li>
                    <li><a href="#"><span uk-pagination-next></span></a></li>
                </ul>   -->
                <div v-if="movies!= ''" class="uk-container uk-container-large uk-margin-large-top" id="dt">
                    <div class="uk-child-width-1-6@m" uk-grid >
                        <div v-for="movie in movarr" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>

                <div v-if="movies!= ''" class="uk-container uk-container-large uk-margin-large-top" id="dtm">
                    <div class="uk-child-width-1-2 " uk-grid >
                        <div v-for="movie in movarr" :key="movie.id">
                            <div class="uk-text-center ">
                                <router-link v-bind:to="'/movies/'+movie.title+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.thumbnail_image_path" alt="">
                                        <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div>
                                        </div>
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>

            </div>
            <nav id="ft" class="uk-navbar-container" uk-navbar style="background:rgb(122, 134, 139);height:43px;">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav uk-margin-large-left">
                        <li class="uk-text-small" style="color:white;"> Saina Movies © All Rights Reserved</li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav uk-margin-left">
                        <li class="uk-text-small" style="color:white; padding-right:30px;" >Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Terms of use</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:70px;">Privacy Policy</li>
                    </ul>
                </div>
            </nav>
        </div> 
</template>
<script>
export default {
    data(){
        return{
            name1: "",
            email: "",
            srch: "",
            movies: [],
            searchResults: [],
            noResults: "",
            movname: "",
            id: this.$route.params.id,
            actorname: "",
            actormovies: [],
            movarr: [],
            count: ""
        }
    },
    mounted(){
        this.search();
        this.getmovies();
         this.name1 =  localStorage.getItem('Name');
         this.email =  localStorage.getItem('Email');
     //   this.getcastdetails();
    },
    methods: {
        search(){
            var self = this;
            ////console.log(self.srch);
            axios.get('https://app.sainavideo.com/vdocipher/api/search/?keyword='+self.srch)
            .then(function(response){

                ////console.log(response.data);  
            
                self.searchResults = response.data.results;
                ////console.log(self.searchResults);
                self.noResults = self.searchResults.length === 0;
                        
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });
        },
        logout() {
            document.location.href = "https://www.google.com/accounts/Logout?continue=https://appengine.google.com/_ah/logout?continue=https://sainavideo.com";
        },
        getmovies(){
            var self = this;      
            axios.get('https://app.sainavideo.com//vdocipher/api/home/')
            .then(function(response){
                ////console.log(response.data);  
                self.banners = response.data.banner;
                self.features = response.data.feature;
                for(var i=0;i<response.data.feature.length;i++){
                    ////console.log(self.features[i].movie);           
                }   
                if( self.id == 'popular'){
                    self.movies = self.features[1].movie;
                    // self.movarr.push(self.movies);
                    // ////console.log(self.movarr);
                    for(var i=0;i<self.features[1].movie.length;i++){
                        self.movarr.push(self.movies[i]); 
                        self.count = i;   
                        if(i == 6)
                        break;       
                    } 

                    self.movname = response.data.feature[1].name;
                }
                if( self.id == 'new'){
                    self.movies = self.features[0].movie;
                    for(var i=0;i<self.features[0].movie.length;i++){
                        self.movarr.push(self.movies[i]); 
                        self.count = i;   
                        if(i == 6)
                        break;       
                    } 
                    self.movname = response.data.feature[0].name;
                }
                if( self.id == 'trending'){
                    self.movies = self.features[2].movie;
                    for(var i=0;i<self.features[2].movie.length;i++){
                        self.movarr.push(self.movies[i]); 
                        self.count = i;   
                        if(i == 6)
                        break;       
                    } 
                    self.movname = response.data.feature[2].name;               
                }
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });   
            
            
            window.onscroll = () => {
                // let bottomOfWindow = document.documentElement.scrollTop + window.innerHeight === document.documentElement.offsetHeight;
                // ////console.log(document.documentElement.scrollTop + window.innerHeight);
                // ////console.log(document.documentElement.offsetHeight);
                // ////console.log(bottomOfWindow);
                // if (bottomOfWindow) {
                var scrollHeight = $(document).height();
                var scrollPosition = $(window).height() + $(window).scrollTop();
                ////console.log(scrollHeight);
                ////console.log(scrollPosition);
                ////console.log((scrollHeight - scrollPosition) / scrollHeight);
                if ((scrollHeight - scrollPosition) / scrollHeight <0.0007) {
                    axios.get('https://app.sainavideo.com//vdocipher/api/home/')
                    .then(function(response){
                        ////console.log(response.data);  
                        self.banners = response.data.banner;
                        self.features = response.data.feature;
                        for(var i=0;i<response.data.feature.length;i++){
                            ////console.log(self.features[i].movie);           
                        }   
                        if( self.id == 'popular'){
                            self.movies = self.features[1].movie;
                            for(var i=self.count+1;i<self.features[1].movie.length;i++){
                                self.movarr.push(self.movies[i]);     
                                self.count = i;      
                            } 

                            self.movname = response.data.feature[1].name;
                        }
                        if( self.id == 'new'){
                            self.movies = self.features[0].movie;
                            for(var i=self.count+1;i<self.features[0].movie.length;i++){
                                self.movarr.push(self.movies[i]);     
                                self.count = i;      
                            } 
                            self.movname = response.data.feature[0].name;
                        }
                        if( self.id == 'trending'){
                            self.movies = self.features[2].movie;
                             for(var i=self.count+1;i<self.features[2].movie.length;i++){
                                self.movarr.push(self.movies[i]);     
                                self.count = i;      
                            } 
                            self.movname = response.data.feature[2].name;               
                        }
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });  
                   //  window.scrollTo(0, 0); 
                }
            };


        }
    }
}
</script>
<style scoped>
.navbar-logo {
  width: 50px;
}


.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.5;
}

.container:hover .middle {
  opacity: 1;

}

.text {
  background-color: black;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
}

@media (max-width: 980px) {
    #dt{
        display:none;
    }
}

@media (min-width: 981px) {
    #dtm{
        display:none;
    }
}
a {
    text-decoration: none;
    }

</style>
