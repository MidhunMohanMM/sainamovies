<template>
    <html>
        <div style="background: url(https://img.yts.am/assets/images/movies/the_predator_2018/background.jpg) no-repeat center center; background-size: cover; -webkit-background-size: cover;-moz-background-size: cover; -o-background-size: cover;">
            <nav class="uk-navbar-container" uk-navbar style="background:black;height:50px;">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav">
                        <li><a class="uk-navbar-toggle uk-hidden@l" uk-navbar-toggle-icon href="#" type="button" uk-toggle="target: #offcanvas-push"></a></li>
                        <li ><router-link v-bind:to="'/profile'" uk-icon="user"></router-link></li>
                        <li ><router-link v-bind:to="'/profile'">{{ name }}</router-link></li>
                    </ul>
                </div>

                <div id="offcanvas-push" uk-offcanvas="mode: push; overlay: true">
                    <div class="uk-offcanvas-bar uk-flex uk-flex-column">
                        <button class="uk-offcanvas-close" type="button" uk-close></button>
                        <ul class="uk-nav uk-nav-primary uk-nav-center uk-margin-auto-vertical" uk-nav="multiple: true">
                            <img class="uk-border-circle" width="80" height="80" src="../assets/images/a1.png">
                        <li class="uk-nav-header uk-text-capitalize uk-text-large" onTranslate="global.menu.title">{{ name }}</li>
                        <li class=" uk-text-lowercase " onTranslate="global.menu.subtitle">{{ email }}</li>
                        <li class="uk-divider-icon uk-margin-remove-bottom"></li>
                        <li>
                            <a ><router-link v-bind:to="'/profile'"><span uk-icon="user"></span> My Account</router-link></a>
                        </li>
                        <!-- <li class="uk-parent">
                            <a>News</a>
                            
                        </li> -->
                        <li class="uk-parent">
                            <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="heart"></span> My Watchlist</a>

                        </li>
                        <li class="uk-parent">
                            <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="commenting"></span> Help</a>

                        </li>
                        <li class="uk-parent">
                            <a class="uk-nav-header uk-text-capitalize" href="#"><span uk-icon="info"></span> Terms of Use</a>

                        </li>

                        <li>
                            <a class="uk-nav-header uk-text-capitalize" href='#'><span uk-icon="list"></span> Privacy Policy</a>
                        </li>
                        <li>
                            <a class="uk-nav-header uk-text-capitalize" @click="logout()"><span uk-icon="sign-out"></span> Log Out</a>
                        </li>
                
                        <hr class="uk-nav-divider">
                        </ul>
                    </div>
                </div>

                <div class="uk-navbar-center">
                    <ul class="uk-navbar-nav">
                        <li ><router-link v-bind:to="'/movies'"><a  style="color:darkorange;font-size:30px;text-decoration:none;" class="uk-text-capitalize">Saina</a></router-link></li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <div>
                        <a class="uk-navbar-toggle" uk-search-icon href="#"></a>
                        <div class="uk-drop"  uk-drop="mode: click; pos: left-center; offset: 0">
                            <form class="uk-search uk-search-navbar uk-width-1-1">
                                <input style="color:white;" v-on:input="search" v-on:focus="search" v-model="srch" class="uk-search-input" type="search" placeholder="Search..." autofocus>
                                <div uk-dropdown="animation: uk-animation-slide-top-small; duration: 1000" v-if="srch!= ''"  style="background:black;margin-top:0px;">
                                    <ul v-for="searchResult in searchResults"  :key="searchResult.id" v-if="!noResults" class="uk-nav uk-dropdown-nav" >
                                        <li  class="uk-active">
                                            <a style="color:white;" href="#">{{ searchResult.title }}</a>                           
                                        </li>
                                    </ul>
                                    <ul  v-if="noResults" class="uk-nav uk-dropdown-nav">
                                        <li >
                                            <a style="color:white;" href="#">No Results found</a>
                                        </li>
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </nav>
            <button @click="back" class="uk-position-top uk-margin-large-top uk-margin-large-left" style="z-index:+1;background-color: transparent; border: none;"><img src="../assets/images/back_arrow.png"  height="40" width="35"></button>
            <div class="uk-cover-container uk-height-medium">
                <img :src="moviedetail.poster_image" alt="" uk-cover >  
            </div>   
            <br>
            <router-link v-bind:to="'/movies/'+title+'/'+moviedetail.id_v+'/watch'">
            <!-- <div @click="movieplay()"> -->
                <img src="../assets/images/play1.png"  alt="" class="uk-padding-small btn" style=" z-index: 1;position: absolute;left: 50%;top: 135px;width: 120px;height: 120px;">
            <!-- </div> -->
            </router-link>
            <img :src="moviedetail.thumbnail_image_path" alt="" class="uk-padding-small uk-width-1-5 uk-height-1-4" style="    z-index: 1;position: absolute;left: 74px;top: 233px;">
            <div style="color:white;padding-left: 30%">   
                <h2 style="color:white;">{{ title }}</h2>
                <button @click="toggleSeen" value="Add to Watchlist" id="wl" class="uk-align-right uk-width-1-3 uk-margin-large-right uk-button uk-button-secondary">{{ button.text }}</button>
                <p style="color:white;">{{length}} mins</p>
                <p style="color:white;" class="uk-text-capitalize">{{tags.tags}}</p>
                <p style="color:white;">{{language}} {{release_year}}</p>
                <div v-if="moviedetail.rating!=null">
                    <div v-if="moviedetail.rating=='5.00'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='4.50'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div v-if="moviedetail.rating=='4.00'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='3.50'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='3.00'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='2.50'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='2.00'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='1.50'">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='1.00'">
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <div v-if="moviedetail.rating=='0.50'">
                        <i class="fas fa-star-half-alt"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                </div>
            </div>
            <br><br>
            <h4 style="color:white;" class="uk-margin-large-left"> SYNOPSIS </h4>
            <p style="color:white;" class="uk-margin-large-left uk-margin-large-right">{{description}}</p>
            <p class="uk-margin-large-left uk-margin-large-right" uk-margin><br>
                <router-link v-bind:to="'/movieplay/'+moviedetail.id_v">
                    <button id="dt1" class="uk-button uk-button-default uk-margin-large-left uk-align-left uk-width-2-5" style="border-color: transparent;color:white; background-image: linear-gradient(to right, #f5920b, #dc3267);">Resume</button>
                </router-link>
                <router-link v-bind:to="'/movies/'+title+'/'+moviedetail.id_v+'/watch'">
                    <button id="dt2" class="uk-button uk-button-default uk-align-right uk-margin-right uk-width-2-5"  style="border-color: transparent;background-color: #7a868b;color:white;">Play from Start</button>
                </router-link>



                <!-- <router-link v-bind:to="'/movieplay/'+moviedetail.id_v">
                    <button id="dtm" class="uk-button uk-button-default uk-align-center " style="border-color: transparent;width:490px;color:white; background-image: linear-gradient(to right, #f5920b, #dc3267);">Resume</button>
                </router-link>
                <router-link v-bind:to="'/movies/'+title+'/'+moviedetail.id_v+'/watch'">
                    <button id="dtm" class="uk-button uk-button-default uk-align-center"  style="border-color: transparent;width:490px; background-color: #7a868b;color:white;">Play from Start</button>
                </router-link> -->



            </p>
            <br>
            <p style="color:white;padding-left:10px;;padding-top:20px;padding-bottom:20px;">CAST AND CREW ></p>
            <div  class="uk-position-relative uk-visible-toggle uk-light " uk-slider="sets: true" >
                <ul class="uk-slider-items uk-margin-left " >
                    <li v-for="cast in casting" :key="cast.id"  style="width:15%">
                        <router-link v-bind:to="'/cast/'+cast.name+'/'+cast.id">
                            <div class="uk-inline-clip uk-transition-toggle" tabindex="0"   >
                            <img :src="cast.image" alt="" class="uk-transition-scale-up uk-transition-opaque uk-align-center" style="height:160px;width:160px;" >
                            <p class="uk-text-center uk-text-capitalize" style="color:white;"> {{ cast.name }}</p>
                            </div>
                            
                        </router-link>
                    </li>           
                </ul>
                <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>
            </div>
            <p style="color:white;padding-left:10px;;padding-top:20px;padding-bottom:20px;">SIMILAR MOVIES ></p>

            <div id="pplr"  class="uk-position-relative uk-visible-toggle uk-light uk-margin-large-bottom" uk-slider="sets: true;autoplay: true">
                <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-5@m"  style="width:1073px;">
                    <li  v-for="movie in similarmovies" :key="movie.id">     
                        <div class="uk-text-center">
                            <router-link v-bind:to="'/movies/'+movie.name+'/'+movie.id_v">
                                <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">              
                                    <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.poster" alt="">
                                </div>
                            </router-link>
                            <p v-if="movie.name!=null" class="uk-margin-top" style="color:white">{{ movie.name }}</p>  
                        </div>  
                    </li>
                </ul>
                <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>
            </div>

              <div id="pplrm" class="uk-container uk-container-large uk-margin-large-top uk-margin-large-bottom">
                    <div uk-grid >
                        <div v-for="movie in similarmovies" :key="movie.id">
                            <div class="uk-text-center">
                                <router-link v-bind:to="'/movies/'+movie.name+'/'+movie.id_v">
                                    <div class="uk-inline-clip uk-transition-toggle container" tabindex="0">                            
                                        <img class="uk-transition-scale-up uk-transition-opaque image" :src="movie.poster" alt="">
                                        <!-- <div v-if="movie.rating!=null || movie.skills.tags!=null" class="middle">
                                            <div v-if="movie.skills.tags!=null" class="text uk-text-capitalize">{{movie.skills.tags}}</div>
                                            <div v-if="movie.rating!=null" class="text">Rating: {{movie.rating}}/5</div> -->
                                        <!-- </div> -->
                                    </div>
                                </router-link>
                                <p v-if="movie.title!=null" class="uk-margin-top" style="color:white">{{ movie.title }}</p>                 
                            </div> 
                        </div>               
                    </div>
                </div>


            <div id="modal-center" class="uk-flex-top" uk-modal>
                <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
                    <button class="uk-modal-close-default" type="button" uk-close></button>
                    <p class="uk-text-center">Please login to continue</p>
                    <hr>
                    <div class="uk-align-left">
                        <p>Sign in using Facebook</p>
                        <button @click="FBLogin()" class="uk-button uk-button-primary" style="background-color: transparent;width:120px;background-color: #3a5695;"><i class="fab fa-facebook-f" ></i></button>
                    </div>
                    <!-- <hr class="uk-divider-vertical"> -->
                    <div class="uk-align-right">
                    
                    <p style="margin-right:15px;" >Sign in using Google</p>
                    <div   id="google-signin-btn" class="g-signin2" data-onsuccess="onSignIn" data-theme="dark" ></div>
                   </div>
                    <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> -->
                </div>
            </div>

            <nav id="ft" class="uk-navbar-container" uk-navbar style="background:rgb(122, 134, 139);height:43px;">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav uk-margin-large-left">
                        <li class="uk-text-small" style="color:white;"> Saina Movies © All Rights Reserved</li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav uk-margin-left">
                        <li class="uk-text-small" style="color:white; padding-right:30px;" >Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Terms of use</li>
                        <li class="uk-text-small" style="color:white;padding-right:30px;">Help</li>
                        <li class="uk-text-small" style="color:white;padding-right:70px;">Privacy Policy</li>
                    </ul>
                </div>
            </nav>
        </div>
    </html>
</template>
<script>
import UIkit from 'uikit'
import JQuery from 'jquery'
let $ = JQuery
export default {
  data(){
    return {
        name: "",
        email: "",
        srch: "",
        description: "",
        moviedetail: "",
        length: "",
        title: "",
        searchResults: [],
        hrs: "",
        noResults: "",
        tags: "",
        skills: {},
        similarmovies: [],
        categories: "Comedy, Adventure",
        language : "",
        release_year : "1987",
        id: this.$route.params.id,
        casting: [],
        release_year: "",
        button: {
            text: 'Add to Watchlist'
        },
        seen: true,
        sub:{
            bookmark_id: ""
        },
        subr: {
            grant_type: "refresh_token",
            client_id: "",
            refresh_token: ""
        },
        subl: {
                grant_type: "convert_token",    
                backend: "google-oauth2", 
                client_id: "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7", 
                token: ""
        },
        accessToken: "",
        user_type: ""
    }
  },
  mounted(){
    var self = this;
    this.getDetail();
    this.tokenrefresh();
    self.name =  localStorage.getItem('Name');
          self.email =  localStorage.getItem('Email');
    
     gapi.signin2.render('google-signin-btn', { // this is the button "id"
            onsuccess: this.onSignIn // note, no "()" here
        })
        $('#signinButton').click(function() {
            auth2.grantOfflineAccess().then(signInCallback);
        });
  },
watch: {
    // call again the method if the route changes
    '$route': 'getDetail',
    
     //id: this.$route.params.id,
  },
  methods: {
      movieplay(){
           var name =  localStorage.getItem('Name');
           var server_access_token = localStorage.getItem('server_access_token');
           ////console.log(server_access_token);
           self.$router.push('/movies/'+self.title+'/'+self.moviedetail.id_v+'/watch'); 
            // if(name != 'Guest'){
            //     axios.get('https://app.sainavideo.com/vdocipher/api/me/',{
            //     headers: {'Authorization': 'Bearer '+server_access_token},
            //     })
            //     .then(function(response){
            //         ////console.log(response.data); 
            //         self.me = response.data.me;
            //         self.user_type = response.data.me.user_type;
            //     //   ////console.log(response.data.me.user_plan);
            //     })
            //     .catch(function (error) {
            //         ////console.log('An Error occured',  error);
            //     });
            //     if( self.user_type == 'premium' ){
            //         self.$router.push('/movies/'+self.title+'/'+self.moviedetail.id_v+'/watch'); 
            //     }

               
            // }
            // else{
            //     var self = this;
            //     self.$router.push('/movies/'+self.title+'/'+self.moviedetail.id_v+'/watch'); 
            // }
      },
        search(){
            var self = this;
            ////console.log(self.srch);
            axios.get('https://app.sainavideo.com/vdocipher/api/search/?keyword='+self.srch,{
            })
            .then(function(response){

                ////console.log(response.data);  
            
                self.searchResults = response.data.results;
            ////console.log(self.searchResults);
            self.noResults = self.searchResults.length === 0;
                        
            })
            .catch(function (error) {
                ////console.log('An Error occured',  error);
            });
    },
    onSignIn(googleUser) {
             $('#modal-center').trigger('click'); 
             var profile = googleUser.getBasicProfile();
             ////console.log(profile);
             var self = this;
             localStorage.setItem('Name', profile.getGivenName() );
            localStorage.setItem('Email', profile.getEmail());
             self.name =  localStorage.getItem('Name');
             var GoogleAuth = gapi.auth2.getAuthInstance();
              var access_token = GoogleAuth.currentUser.Ab.Zi.access_token;
              localStorage.setItem('access_token', access_token );
              self.convert();
             
            //   self.$router.replace ({ name: "home"});
             
    },
    convert(){
        var self = this;
        var access_token = localStorage.getItem('access_token');
         self.subl.token = access_token;
         //console.log(self.subl);
              axios.post('https://app.sainavideo.com/auth/convert-token/',self.subl)
                .then(function(response){

                
                        localStorage.setItem('server_access_token', response.data.access_token);
                        localStorage.setItem('refresh_token', response.data.refresh_token);
                })
                .catch(function (error) {
                    ////console.log('An Error occured',  error);
                });
    },
    back(){
        var self = this;
        self.$router.replace ({ name: "home"});
    },
      FBLogin(){
            var self = this;
            FB.login(function(response) {
                if (response.authResponse) {
                ////console.log('Welcome!  Fetching your information.... ');
                FB.api('/me', function(response) {
                ////console.log('Good to see you, ' + response.name + '.');
                ////console.log(response);
                self.accessToken = FB.getAuthResponse().accessToken;
                ////console.log(self.accessToken);
                self.sub.token = self.accessToken;
                ////console.log(self.sub);
                    axios.post('https://app.sainavideo.com/auth/convert-token/',self.subl)
                    .then(function(response){

                        ////console.log(response.data);  
                         self.$router.replace({ name: "movie" });                               
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                });
                } else {
                ////console.log('User cancelled login or did not fully authorize.');
                }
            });
        },
    tokenrefresh(){
            var self = this;

            var started = localStorage['started'];
            if (started) {

                var diff = Date.now() - started;

                if (diff >= 1000 ) {
                    self.subr.client_id =  "QvkFkTpUdh3tOu7MjIPm0V5XDrn2tTxIoe0Qk4c7";
                    self.subr.refresh_token =  localStorage.getItem('refresh_token');
                
                    axios.post('https://app.sainavideo.com/auth/token/',self.subr)
                    .then(function(response){
                     //   console.log(response.data);
                    
                        localStorage.setItem('server_access_token', response.data.access_token);       
                    })
                    .catch(function (error) {
                        ////console.log('An Error occured',  error);
                    });
                }
            }
             else {
                localStorage['started'] = Date.now();
            }
                  
        },
    toggleSeen() {
        var self = this;
        var name =  localStorage.getItem('Name');
        if(name != 'Guest'){
            ////console.log(self.button.text);
            self.seen = !self.seen;
            self.button.text = self.seen ? 'Add to Watchlist' : ' ✓ Added to Watchlist';
            var server_access_token = localStorage.getItem('server_access_token');
            ////console.log(server_access_token);
            if(self.button.text == ' ✓ Added to Watchlist')
            {
                axios.post('https://app.sainavideo.com/vdocipher/api/addwatchlist',self.sub,{
                    headers: {'Authorization': 'Bearer '+server_access_token}
                })
                .then(function(response){
                    ////console.log(response.data);               
                })
                .catch(function (error) {
                    ////console.log('An Error occured',  error);
                });
            }
            else{
                axios.post('https://app.sainavideo.com/vdocipher/api/deletewatchlist',self.sub,{
                headers: {'Authorization': 'Bearer '+server_access_token}
                })
                .then(function(response){
                    ////console.log(response.data);           
                })
                .catch(function (error) {
                    ////console.log('An Error occured',  error);
                });
            }

        }
        else{
                var modal = UIkit.modal("#modal-center");
                modal.show(); 
            //alert('Please login to add to watchlist');
        }
    },
    logout() {
            document.location.href = "https://www.google.com/accounts/Logout?continue=https://appengine.google.com/_ah/logout?continue=https://sainavideo.com";
    },
    getDetail(){
        window.scrollTo(0, 0);
        var self = this;          
        this.id = self.$route.params.id2  ;
        ////console.log(this.id);
        axios.get('https://app.sainavideo.com//vdocipher/api/movie/'+this.id+'/',{
        })
        .then(function(response){
            ////console.log(response.data);  
            self.moviedetail = response.data.movie_detail;
            ////console.log( self.moviedetail);
            self.similarmovies = response.data.movie_detail.similar_list;
            self.description = response.data.movie_detail.description;
            self.title = response.data.movie_detail.title;
            self.length = response.data.movie_detail.length;
            self.language = response.data.movie_detail.language;
            self.release_year = response.data.movie_detail.release_year;
            self.tags = response.data.movie_detail.skills;
            self.casting = response.data.movie_detail.casting;
            self.length = self.length.split(":"); 
            self.hrs =  Number(self.length[0]*60);  
            self.length = Number(self.hrs)+Number(self.length[1]);
            self.release_year = self.release_year.split("-");       
            self.release_year = self.release_year[0];
            for(var i=0;i<response.data.movie_detail.casting.length;i++){
                ////console.log(self.casting[i]);          
            }   
            self.sub.bookmark_id = response.data.movie_detail.id;
            ////console.log(self.casting);
        })
        .catch(function (error) {
            ////console.log('An Error occured',  error);
  });
      }
    } 
}
</script>

<style scoped>
@media (max-width: 818px) {
    #wl{
        display: none;
    }
    #dt2{
        margin-left:0px;
        margin-right:0px;
    }
    #dt1{
        margin-left:0px;
        margin-right:0px;
    }
}

@media screen and (max-width: 980px) {
    #pplr{
        display:none;
    }
    /* #ft{
        height:95px;
    } */
}

@media screen and (min-width: 981px) {

  #pplrm{
        display:none;
    }

}

/* @media (max-width: 1430px) {
    #dt{
        display:none;
    }
}

@media (min-width: 1431px) {
    #dtm{
        display:none;
    }
} */
a {
    text-decoration: none;
    }
</style>
